# If a machine "asks RINA" for the Map-Resolver: what rlite does at its lowest layer (rlite 6ac276b)

| shim (lowest DIF) | how it turns a RINA application name into a locator | source |
|---|---|---|
| shim-udp4 (over IP) | the system resolver: `getaddrinfo(<RINA name>)`, i.e. DNS or /etc/hosts | user/uipcps/uipcp-shim-udp4.c `rina_name_to_ipaddr` |
| shim-eth (one LAN) | an ARP broadcast carrying the application name | kernel/shim-eth.c (ETH_P_ARP requests, ARP table) |

- **Above the shims,** a normal DIF's directory answers names, but only for a machine already enrolled, which a new
  machine is not.
- **So over IP, asking RINA for the Map-Resolver bottoms out in DNS** of a RINA name: lispers.net's option 2 (a
  dns-name for the Map-Resolver), reached through RINA naming.
- **On a LAN it bottoms out in a broadcast,** which is ruled out: no direct propagation.
