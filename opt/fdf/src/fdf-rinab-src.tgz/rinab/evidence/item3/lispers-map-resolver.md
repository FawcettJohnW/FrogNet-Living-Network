# How lispers.net finds its Map-Resolver (from its source, commit in lisp-mapping/LISPERS-COMMIT)

It never discovers one. It is always configured, one of three ways (docs/lisp-config-commands.txt):

| way | config | how it works |
|---|---|---|
| address | `lisp map-resolver { address = 1.1.1.1 }` | several clauses = several Map-Resolvers |
| DNS name | `lisp map-resolver { dns-name = mr1.lispers.net }` | every A record is a Map-Resolver, used in turn; re-resolved on use if >30 s old (lisp.py `lisp_mr.resolve_dns_name`) |
| LISP-Decent | `decentralized-pull-xtr-modulus = 2` + `decentralized-pull-xtr-dns-suffix = map-server.lispers.net` | hash(EID) mod N -> DNS name `<n>.<suffix>`; a cluster of map-servers is the whole mapping system |

For FD&F (proposed, awaiting John):

- `RINA_MAP_RESOLVER` takes an address OR a DNS name, as lispers.net's.
- The DNS name is resolved on use, not on a 30 s schedule.
- LISP-Decent is later, if needed.
