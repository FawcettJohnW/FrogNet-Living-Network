# Item 3: a deterministic rule for where the Map-Resolver is, from the area's name alone (options for John)

Goal: no per-deployment configuration, no DNS. Every machine computes the same answer from the name.

| option | the rule | what has to be agreed | cost |
|---|---|---|---|
| A. LISP-Decent without DNS | hash(area name) mod N picks one of N mapping-system addresses from a fixed published list (like DNS root hints, built in) | the list, once, globally | the list is global knowledge; changing it is a release |
| B. Name-derived anycast address | hash(area name) -> an address in a reserved prefix (an IPv6 /96, or a reserved IPv4 block); whoever serves the area's mapping binds that address | the prefix, once | the deployment must route that anycast address; IPv6 is the natural fit (no IPv6 in this sandbox kernel) |

Both are LISP practice: A is lispers.net's `decentralized-pull-xtr-modulus` with a list in place of `<n>.<dns-suffix>`;
B is anycast Map-Resolvers addressed by rule instead of by configuration.
