# Mode B on the Redis server model: the timed-out turns' tree, re-verified

The tree was rebuilt from source (tools/build.sh, tools/build_rlite.sh) and re-run here. The 1-core sandbox numbers
are this machine's only.

**rlite's 30 tests, RAM host isolated:** 30/30 (suite-isolated-rerun1.tsv). This agrees with the timed-out turns'
recorded 30/30.

**rinaperf, one machine, same run** (bench-rerun1.txt; agrees with results/bench-1.txt):

| | Mode B as handed off | RINA region (Redis model) |
|---|---:|---:|
| ping rtt avg (200) | 0.821 ms | 1.230 ms |
| rr (5000) | 1,179 tps, 848 µs | 856 tps, 1,167 µs |
| perf (20000), received | 2,729 kpps, 30.6 Mbps | 5,035 kpps, 56.4 Mbps |

- **The region is faster for bulk:** perf 1.8x.
- **It is slower for single exchanges:** ping 1.5x, rr 1.4x.
- **The cause of the single-exchange cost is CPU.** results/cpu-split-1.txt has CPU per transaction at 1,170 µs
  against 812 µs. The host's share is 580 µs against 374.
