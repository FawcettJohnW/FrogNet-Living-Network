# What a diffed `send` costs on the FNWP wire (rr-count 300, fdf.prime; tcpdump on lo:8845)

| frames client -> RAM manager | count | what |
|---|---|---|
| 86 bytes | 613 | held waits (`rina_block`) |
| 111–117 bytes | ~590 | posted `send`s, each a diff |

One 113-byte send (evidence/bldc/send-frame-113.txt):

- 4-byte length, `FNW1`, frame type, and a 16-byte request hash;
- the template and location fields;
- the changed value: the WHOLE `sdus` array as JSON, `[["21475-3-c492827e",129,"..\u0000"]]`.

BLDC-1 treats an array as ONE atomic value, so each send carries:

- the flow id (~20 bytes, never changing);
- the sequence number;
- the data;
- the array's punctuation.

A flat single-SDU body (`fid`, `q`, `d`) would let the diff carry only `q` and `d`.
