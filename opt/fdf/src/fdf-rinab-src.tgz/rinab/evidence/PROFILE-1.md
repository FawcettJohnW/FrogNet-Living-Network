# Where the region's per-transaction cost goes (rinaperf rr, 500 transactions, host under callgrind)

The RINA host ran under callgrind, collecting inside `api()` (every region call), while one rinaperf rr of 500
transactions ran. Data: callgrind.out.host, requests-per-session.txt; script: cg-rr.sh.

**Requests per transaction** (the host's own session log):

- client program: 1,506 for 500 transactions;
- server program: 1,445;
- so about 3 per program, 6 per transaction.

The three per program, from librina_region.cpp:

1. `send`, posted;
2. the held `wait` returning the peer's SDU (`k == "s"`);
3. the held `wait` returning a credit event (`k == "c"`): the peer consumed what this program sent.

The credit event wakes the program, and its wait is re-issued, once per transaction, although the sender needs
credit only when it is RING (4,096) SDUs ahead.

**Cost inside the region calls:** 126.7 M instructions for ~2,950 calls, about 43 k per call. The top exclusive
items:

| item | share |
|---|---:|
| malloc / free / new | about 20% |
| JSON parse (`P::val`, `ws`) | about 7% |
| string building | about 10% |
| `Json::quote` | 2.3% |
| hashing | 2.2% |
| strtod and printf of numbers | about 2% |

The records are strings ("k=v;" inside JSON bags) and are parsed and rebuilt on every call.

**Next, in order:**

1. Credit only when it is needed. The region tells a sender about credit only when the sender has reached the RING
   limit, so one wait per program per transaction disappears (6 → 4 requests).
2. Cut the per-call parse and allocation: the record format, and the JSON on the hot path.

---

## Step 1 done: credit on demand (`[CREDIT_ON_DEMAND_V1]`)

**Change.**

- The receiver's consumed count goes into its own cell (`cr`), not into the sender's event stream.
- A sender asks for credit only when it is RING SDUs ahead, with one held read (`op=rina_block credit`).
- Files: src/rina_region.cpp, src/librina_region.cpp.

**Requests per transaction:** 3.0 → **2.00 per program** (10,010 and 10,011 requests for 5,000 rr transactions;
after-credit-on-demand.txt).

**Same run, both builds** (bench-after-credit.txt):

| | Mode B as handed off | RINA region, before | RINA region, now |
|---|---:|---:|---:|
| ping rtt avg | 0.822 ms | 1.230 ms | **0.795 ms** |
| rr | 1,220 tps | 856 tps | **1,292 tps** |
| perf received | 2,822 kpps | 5,035 kpps | 4,020 kpps |

"Before" is bench-rerun1.txt, a separate run.

**What it shows.**

- Ping and rr are now level with or slightly better than the handed-off build.
- Perf, received, is 4,020 kpps against 5,035 in the earlier run. That needs a same-run repeat before it is called
  a change.

**rlite's 30 tests, isolated:** 30/30 (suite-isolated-after-credit.tsv).

- The first run after the change had 0004 and 0012 failing with "Flow 0 timed out" (…-first-run-1to15.tsv).
- Since then: 0004 2/2; 0012 1 failure in 2, then 6/6; and 0012 6/6 on the pre-change tree too
  (0012-before-after.txt).
- So the failures are intermittent and not tied to this change by these runs. The cause is not found.

**Next:** step 2, the per-call parse and allocation (about 43 k instructions per call).

---

## Step 2a: the event read goes out as stored (`[RAW_HELD_READ_V1]`)

**Change.**

- `wait` used to parse every event cell into JSON and then serialize it again for the reply.
- It now sends the bag text exactly as the memory holds it.
- Only an SDU's fid and sequence are read from it, for the credit cell.
- The platform patch adds `rina_resident_wait_raw`.

**Instructions inside region calls, rr of 500** (callgrind; callgrind.out.host before, callgrind.out.step2a after):

| | before step 1 | now |
|---|---:|---:|
| calls | ~2,950 | 2,020 |
| instructions | 126.7 M | 79.2 M |
| per transaction | 253 k | 158 k (−37%) |

**rr, 5,000** (rr-count.sh, separate runs): 1,357 tps after step 1 → **1,637 tps** (611 µs) now. Still 2.00
requests per program per transaction.

**Where the 158 k per transaction is now** (inclusive):

| item | share |
|---|---:|
| `Json::parse` (request bodies, and `get()` reading records) | 25% |
| memory writes | 23% |
| `get()` | 20% |
| `ev()` | 13% |
| `put()` | 11% |
| the platform's URL `query()` | 11% |
| `sess_proc()` (a record lookup per call) | 6% |

**Next, step 2b:**

- `get()` and `sess_proc()` read records by parsing their JSON bag;
- `send` looks up the flow record for every batch.

---

## Step 2b: records read as stored (`[RAW_GET_V1]`)

**Change.**

- `get()`, and `sess_proc()` through it, read a record by parsing its whole JSON bag.
- They now take the cell's bag text and unescape the one string value inside it (`unquote_v`).
- The platform patch adds `rina_resident_get_raw`.

**Instructions inside region calls, rr of 500:** 79.2 M → **72.2 M** (−9%); 144 k per transaction, against 253 k
before step 1 (−43% overall). Still 2.00 requests per program per transaction.

**rr tps on this 1-core machine varies run to run** (1,459 against 1,637 in consecutive single runs). The
instruction counts above are the deterministic measure.

**rlite's 30 tests, isolated:** 30/30 (suite-isolated-after-step2b.tsv).

---

## Step 2c: the credit cell is written only when consumption crosses a quarter of the ring (`[CREDIT_BY_QUARTERS_V1]`)

**Change.** Each `wait` that handed over SDUs used to look up the flow record and write the credit cell (a memory
write that wakes waiters). Now it does so only when the consumed count crosses a multiple of RING/4 (1,024).

**Why a sender can never wait for nothing.** A sender blocks only when a full ring (4,096) is outstanding.
Consuming those SDUs crosses at least one quarter boundary, so the cell is written.

**Build fix found on the way.** tools/build.sh built build/rina-host, but the scripts run build/bin/rina-host, which
only tools/build_rlite.sh refreshed. My first measurement after the change ran the old host (72.3 M, no change).
build.sh now installs build/bin/rina-host as well. The 2a and 2b measurements were made after build_rlite.sh, so they
ran the right host.

**Instructions inside region calls, rr of 500:** 72.3 M → **58.6 M** (−19%); 117 k per transaction (253 k before
step 1: −54% overall). Still 2.00 requests per program per transaction. Data: callgrind.out.step2c.

**Every SDU arrives when credit is exercised.** rinaperf perf of 20,000, more than RING, so the sender runs out of
credit and gets it back by quarters: 20,000 / 20,000 received, three runs (perf-20000-after-step2c.txt).

**rlite's 30 tests, isolated:** 30/30 (suite-isolated-after-step2c.tsv).

---

## Step 2d: the region's two operations are recognized before the query string is parsed (`[REGION_FAST_PATH_V1]`)

**Change.**

- The platform's `api()` parsed every path's query string into a `std::map`, using `std::stringstream` and
  `urldec`: about 4.4 k instructions per call.
- make_host.sh now puts a check of the exact path tail (`?op=rina`, `?op=rina_block`) before that parse.
- The generated host is the only file that changes; the vendored platform is untouched.
- A quote inside the awk program broke make_host on the first try; that is fixed.

**Instructions inside region calls, rr of 500:** 58.6 M → **48.0 M** (−18%); 96 k per transaction (253 k before
step 1: −62% overall). Data: callgrind.out.step2d.

**Run-to-run spread of these totals.** The same step-2c binary measured 58.6 M and 56.7 M in two runs, about 3%.
Differences smaller than that are not changes.

**rlite's 30 tests, isolated: 29/30** (suite-isolated-after-step2d.tsv).

- 0029 failed with "Flow allocation timed out for control flow", then passed 4 of 4 alone.

**OPEN: an intermittent flow-allocation stall in the region build.** It has now been seen three times:

- 0004 and 0012 ("Flow 0 timed out") after step 1;
- 0029 after step 2d.

The pre-change tree passed 0012 6/6, but that is too few runs to clear it. Next: reproduce it on demand and find it.

---

## Fixes after step 2d (found on John's machine and reproduced here)

1. **`[RESOLVE_ONLY_FOR_UDP4_V1]`.** librina resolved the application name (getaddrinfo, so DNS) on every register
   and alloc, whatever the DIF. With the resolver unreachable, a lookup stalled 2 s.
   - Found with tools/alloc-stall.sh plus strace: 2 of 200 one-shot flows took 2.02 s, and the gap was a
     `poll(…, 2000)` on DNS.
   - Now the region answers NEEDIP only when the DIF is a shim-udp4, and only then does the program resolve.
   - After the fix: 0 slow in 400.
2. **`[REGION_ANSWER_IS_DATA_V1]`.** frogram::Session::call throws Refused for `{"ok":false}` even with HTTP 200, so
   every region error (ENOENT, EHOSTUNREACH …) aborted the program instead of setting errno. Aborted rlite-ctl and
   rlite programs are what John saw. The client now hands an ok:false answer back as the answer.
3. **`[OPENSSL_NO_ATEXIT_V1]`.** Segfaults at exit (rc 139). From three cores: thread 1 in `exit_now` running the exit
   handlers; another in `Session::send_loop` → `SHA256` → `CRYPTO_THREAD_read_lock(NULL)`. OpenSSL's atexit cleanup
   had freed its locks under a running thread.
   - Mode B's old client had this fix; the region client had lost it.
   - Provoked under strace: 19 crashes in 150 runs before, **0 in 150** after.
4. **run-suite.sh** appended to an existing results file, so rows from an earlier run could mix in. A run from test 1
   now starts its own table.

**rlite's 30 tests, isolated, with all of the above:** 29/30 (suite-isolated-latest.tsv).

- 0012 failed once ("Flow 0 timed out", 4.08 s), then passed 5/5 alone (0.07–0.09 s).
- The 4 s has the shape of two 2 s DNS timeouts. The test registers a name with no /etc/hosts entry on purpose, and
  this sandbox has no reachable resolver. Not yet proven.

---

## The host stopped taking sessions at test 0024 on AI-Host: it ran out of file descriptors

**Evidence:** John's run.sh dump (john-0024-hostdump-fd-limit.txt). The host was alive and its accept thread was
fine, but the sockets its serve threads held were numbered 993–1022: the default open-file limit is 1,024.

**Cause: sessions never freed their sockets.**

1. The platform's data-socket sender captured the session by `shared_ptr`, and the session owns the sender. That
   cycle meant no session was ever freed, and nothing closed its return and data sockets anyway (they are only shut
   down).
2. A program's held read (`wait`, `credit`) never returned once its session had ended, so its parked request kept the
   session alive.

In this sandbox the open-file limit is far higher, so the suite never reached it.

**Fix:**

- `[SESSION_FREES_ITS_SOCKETS_V1]` (platform patch): the sender holds the session weakly; `~Session` closes the return
  and data sockets.
- `[HELD_READS_END_WITH_THE_SESSION_V1]` (region): when a program's session ends, its held `wait` is answered and any
  `credit` wait for its flows ends.

**Measured at John's limit (`ulimit -n 1024`).** run.sh now records the host's open descriptors after every test.

| | before the fix | after the fix |
|---|---|---|
| host descriptors, test 1 → 23 | 16 → 995 | **4 → 4** |
| test 0024 | did not get that far | passes |
| tests 24–30 | — | 7/7 pass |

**Also new in run.sh:** it stops if network namespaces are left over from an earlier run, as "green" was here. That
leftover failed 0024 once, with "File exists".

**Still open:** a full run launched in the background here (setsid/nohup) had 4 tests fail with rinaperf's "Flow
allocation timed out" (0004, 0011, 0012, 0014). Their descriptors stayed at 4. Foreground runs of the same build pass,
and John's terminal run passed every test up to 0024.
