// fdf_watch.cpp -- [FDF_WATCH_V1] the participants, held: ONE session to the RAM manager, ONE watch on it, for as long
// as it runs. Prints one line {"gen":N,"participants":[...]} now and one more on every change (a machine joins,
// announces, or its session ends). Windows and Linux alike (built like fdf-client, on frogram::Session only), so
// fdf-ls --watch and fdf-browser run on either.
//     fdf-watch <ram-server>:<port>      (or RINA_RAM)
// The watch is registered before the first list is read, so no change falls between them. When the session ends it
// says why and exits 1 (no retry). Each participant: hostname, alive, ips, ns, cores, mem_total_kb, os.
#include "frogram.hpp"
#include <cstdio>
#include <cstdlib>
#include <string>
#ifdef _WIN32
#include <process.h>
#define getpid _getpid
#else
#include <unistd.h>
#endif

static const char* API = "/FawcettInnovations.RINA.ram_interface.php";

static std::string list(frogram::Session& s) {
    frogram::Json r = s.call("POST", std::string(API) + "?op=rina", "{\"op\":\"participants\"}");
    if (!r["ok"].b) throw std::runtime_error("participants refused: " + r["error"].s);
    std::string out = "["; bool f = true;
    for (auto& p : r["participants"].a) {
        std::string ips = "["; bool g = true; for (auto& a : p["ips"].a) { ips += (g ? "" : ",") + frogram::Json::quote(a.s); g = false; } ips += "]";
        out += std::string(f ? "" : ",") + "{\"hostname\":" + frogram::Json::quote(p["name"].s) + ",\"alive\":" + (p["alive"].b ? "true" : "false") +
               ",\"ips\":" + ips + ",\"ns\":" + frogram::Json::quote(p["ns"].s) + ",\"cores\":" + std::to_string((long)p["cap"]["cores"].n) +
               ",\"mem_total_kb\":" + std::to_string((long long)p["cap"]["mem_total_kb"].n) + ",\"os\":" + frogram::Json::quote(p["cap"]["os"].s) + "}";
        f = false; }
    return out + "]";
}

int main(int argc, char** argv) {
    const char* e = getenv("RINA_RAM"); const std::string where = argc > 1 ? argv[1] : (e ? e : "");
    const size_t c = where.rfind(':');
    if (where.empty() || c == std::string::npos) { fprintf(stderr, "usage: fdf-watch <ram-server>:<port>   (or set RINA_RAM)\n"); return 2; }
    const std::string api = API, me = "watch:" + std::to_string(getpid());
    try {
        frogram::Session s(where.substr(0, c), atoi(where.c_str() + c + 1), api);
        frogram::Json r = s.call("POST", api + "?op=rina", "{\"op\":\"watch_participants\",\"proc\":" + frogram::Json::quote(me) + "}");
        if (!r["ok"].b) { fprintf(stderr, "fdf-watch: the watch was refused: %s\n", r["error"].s.c_str()); return 1; }
        for (unsigned long long gen = 0;;) {
            printf("{\"gen\":%llu,\"participants\":%s}\n", gen, list(s).c_str()); fflush(stdout);
            // held until an event past `gen` is in this watch's input space: "E\n" then "<n>\t<event>\n" lines
            const std::string t = s.call_text("POST", api + "?op=rina_block", "{\"op\":\"wait\",\"proc\":" + frogram::Json::quote(me) +
                                              ",\"after\":" + std::to_string(gen) + "}", 3.0e8);
            if (t.compare(0, 2, "E\n") != 0) throw std::runtime_error("the held wait answered: " + t.substr(0, 200));
            for (size_t p = 2; p < t.size();) { const size_t tab = t.find('\t', p), nl = t.find('\n', p); if (tab == std::string::npos || nl == std::string::npos) break;
                const unsigned long long n = std::stoull(t.substr(p, tab - p)); if (n > gen) gen = n; p = nl + 1; }
        }
    } catch (const std::exception& x) { fprintf(stderr, "fdf-watch: the session to %s ended: %s\n", where.c_str(), x.what()); return 1; }
}
