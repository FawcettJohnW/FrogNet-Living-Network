// fdf_client.cpp -- [FDF_WINDOWS_CLIENT_V1] (experiments/DESIGN-WINDOWS-CLIENT.md) an FD&F member as one small program,
// Windows and Linux alike: the FD&F client owns this machine's connection to the region, so applications on it just get
// and set. It does what the Linux agent does for membership, and nothing else:
//   connect   one FNWP session to the region's RAM manager (RINA_RAM=host:port, or the first argument)
//   alive     writes this machine's node record on that session, so the RAM manager counts it alive while it runs
//   announce  its name (computer name), its IPv4 addresses, its capability (cores, memory)
//   hold      a held read on its own input space; when the session ends it says why and exits
#include "frogram.hpp"
#include <cstdio>
#include <cstdlib>
#include <string>
#include <thread>
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <windows.h>
#else
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <sys/sysinfo.h>
#include <unistd.h>
#endif

static const char* API = "/FawcettInnovations.RINA.ram_interface.php";

static std::string host_name() {
#ifdef _WIN32
    char b[256]; DWORD n = sizeof b; if (GetComputerNameA(b, &n)) return std::string(b, n); return "windows";
#else
    char b[256] = "?"; gethostname(b, sizeof b - 1); return b;
#endif
}
static std::string ipv4s() {                          // this machine's own non-loopback IPv4 addresses, as a JSON array
    std::string out = "["; bool f = true;
#ifdef _WIN32
    ULONG len = 15000; std::string buf(len, '\0');
    auto* a = reinterpret_cast<IP_ADAPTER_ADDRESSES*>(&buf[0]);
    if (GetAdaptersAddresses(AF_INET, GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST | GAA_FLAG_SKIP_DNS_SERVER, nullptr, a, &len) == NO_ERROR)
        for (; a; a = a->Next) {
            if (a->OperStatus != IfOperStatusUp || a->IfType == IF_TYPE_SOFTWARE_LOOPBACK) continue;
            for (auto* u = a->FirstUnicastAddress; u; u = u->Next) {
                char ip[INET_ADDRSTRLEN]; inet_ntop(AF_INET, &reinterpret_cast<sockaddr_in*>(u->Address.lpSockaddr)->sin_addr, ip, sizeof ip);
                out += (f ? "" : ",") + frogram::Json::quote(ip); f = false; } }
#else
    ifaddrs* ia = nullptr;
    if (getifaddrs(&ia) == 0) { for (ifaddrs* a = ia; a; a = a->ifa_next) {
        if (!a->ifa_addr || a->ifa_addr->sa_family != AF_INET || (a->ifa_flags & IFF_LOOPBACK)) continue;
        char ip[INET_ADDRSTRLEN]; inet_ntop(AF_INET, &reinterpret_cast<sockaddr_in*>(a->ifa_addr)->sin_addr, ip, sizeof ip);
        out += (f ? "" : ",") + frogram::Json::quote(ip); f = false; } freeifaddrs(ia); }
#endif
    return out + "]";
}
static std::string capability() {                     // what this OS reports; the same field names as FrogNet's probe
    unsigned long long mem_kb = 0;
#ifdef _WIN32
    MEMORYSTATUSEX m; m.dwLength = sizeof m; if (GlobalMemoryStatusEx(&m)) mem_kb = m.ullTotalPhys / 1024;
    const char* os = "windows";
#else
    struct sysinfo si; if (sysinfo(&si) == 0) mem_kb = (unsigned long long)si.totalram * si.mem_unit / 1024;
    const char* os = "linux";
#endif
    return "{\"cores\":" + std::to_string(std::thread::hardware_concurrency()) + ",\"mem_total_kb\":" + std::to_string(mem_kb) +
           ",\"os\":\"" + os + "\",\"client\":\"fdf-client\"}";
}

int main(int argc, char** argv) {
    const char* e = getenv("RINA_RAM"); const std::string where = argc > 1 ? argv[1] : (e ? e : "");
    const size_t c = where.rfind(':');
    if (where.empty() || c == std::string::npos) { fprintf(stderr, "usage: fdf-client <ram-server>:<port>   (or set RINA_RAM)\n"); return 2; }
    const std::string name = host_name(), ns = "w:" + name, api = API;
    try {
        frogram::Session s(where.substr(0, c), atoi(where.c_str() + c + 1), api);
        auto rina = [&](const std::string& body) { return s.call("POST", api + "?op=rina", body); };
        frogram::Json r = rina("{\"op\":\"node\",\"ns\":" + frogram::Json::quote(ns) + ",\"devs\":\"\"}");                 // alive: this session
        const unsigned long long after = (unsigned long long)r["after"].n;
        r = rina("{\"op\":\"announce\",\"ns\":" + frogram::Json::quote(ns) + ",\"name\":" + frogram::Json::quote(name) +
                 ",\"ips\":" + ipv4s() + ",\"cap\":" + frogram::Json::quote(capability()) + "}");
        if (!r["ok"].b) { fprintf(stderr, "fdf-client: the announcement was refused: %s\n", r["error"].s.c_str()); return 1; }
        printf("fdf-client: %s joined the region at %s, announced %s\n", name.c_str(), where.c_str(), ipv4s().c_str()); fflush(stdout);
        for (unsigned long long at = after;;) {                                    // hold: the session IS this machine's membership
            const std::string t = s.call_text("POST", api + "?op=rina_block", "{\"op\":\"wait\",\"proc\":" + frogram::Json::quote("agent:" + ns) +
                                              ",\"after\":" + std::to_string(at) + "}", 3.0e8);
            for (size_t p = 2; p < t.size();) { const size_t tab = t.find('\t', p), nl = t.find('\n', p); if (tab == std::string::npos || nl == std::string::npos) break;
                const unsigned long long n = std::stoull(t.substr(p, tab - p)); if (n > at) at = n; p = nl + 1; }
        }
    } catch (const std::exception& x) { fprintf(stderr, "fdf-client: the session to %s ended: %s\n", where.c_str(), x.what()); return 1; }
}
