# browser_e2e.py URL TARGET OUTDIR -- the page as a person uses it: click the machine, log in, run commands, log out
import sys, time
from playwright.sync_api import sync_playwright
url, target, out = sys.argv[1:4]
def screen(page): return page.evaluate("() => [...document.querySelectorAll('.term.on .xterm-rows > div')].map(d => d.textContent).join('\\n')")
def until(page, text, limit=10):
    t0 = time.time()
    while text not in screen(page):
        if time.time() - t0 > limit: raise SystemExit("TIMEOUT %r\n%s" % (text, screen(page)))
        time.sleep(0.02)
    return time.time() - t0
with sync_playwright() as p:
    b = p.chromium.launch(); page = b.new_page(viewport={"width": 1100, "height": 650})
    page.goto(url); page.wait_for_selector(".t.can")
    page.screenshot(path=out + "/1-targets.png")
    t0 = time.time(); page.click(".t.can:has-text('%s')" % target)
    print("login prompt   %.3fs" % until(page, "login:"))
    page.keyboard.type("frog\n"); until(page, "assword")
    page.keyboard.type("frogpass\n"); until(page, "$ ")
    t1 = time.time(); page.keyboard.type("echo hello-$((6*7))\n"); until(page, "hello-42"); print("command        %.3fs" % (time.time() - t1))
    page.keyboard.type("stty size; uname -n; ls --color=always /\n"); until(page, "usr")
    print("stty/uname     ", [l for l in screen(page).splitlines() if l.strip()][-6:-2])
    page.screenshot(path=out + "/2-session.png")
    page.set_viewport_size({"width": 800, "height": 500}); time.sleep(0.3)
    page.keyboard.type("stty size\n"); time.sleep(0.5)
    print("after resize   ", [l for l in screen(page).splitlines() if l.strip()][-2])
    page.keyboard.type("exit\n"); until(page, "logout")
    print("end            ", [l for l in screen(page).splitlines() if l.strip()][-1])
    page.screenshot(path=out + "/3-ended.png")
    b.close()
