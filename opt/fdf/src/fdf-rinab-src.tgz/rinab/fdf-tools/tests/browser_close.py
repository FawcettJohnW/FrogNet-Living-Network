# browser_close.py URL TARGET -- log in, then (1) close the tab with its X, (2) log in again and close the whole page
import sys, time
from playwright.sync_api import sync_playwright
url, target = sys.argv[1:3]
def screen(page): return page.evaluate("() => [...document.querySelectorAll('.term.on .xterm-rows > div')].map(d => d.textContent).join('\\n')")
def until(page, text):
    t0 = time.time()
    while text not in screen(page):
        if time.time() - t0 > 10: raise SystemExit("TIMEOUT %r" % text)
        time.sleep(0.02)
def login(page):
    page.click(".t.can:has-text('%s')" % target); until(page, "login:")
    page.keyboard.type("frog\n"); until(page, "assword"); page.keyboard.type("frogpass\n"); until(page, "$ ")
with sync_playwright() as p:
    b = p.chromium.launch(); page = b.new_page(); page.goto(url); page.wait_for_selector(".t.can")
    login(page); page.click(".tab button"); print("tab closed"); time.sleep(1)
    login(page); page.close(); print("page closed"); time.sleep(1)
    b.close()
