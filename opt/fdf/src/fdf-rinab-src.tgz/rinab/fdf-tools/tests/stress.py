# stress.py HOST:PORT SECONDS -- held reads + writes + reads + deletes concurrently; count and classify failures
import sys, threading, time, collections
sys.path.insert(0, "/opt/fdf/lib/python"); import fdfram
ram = fdfram.Ram(sys.argv[1]); end = time.time() + float(sys.argv[2]); errs = collections.Counter(); ok = collections.Counter()
def held(i):
    last = 0
    while time.time() < end:
        try: c = ram.read("st", "h%d" % i, after=last, wait_s=2); last = max([x["id"] for x in c] + [last]); ok["held"] += 1
        except Exception as e: errs["held: %s" % e] += 1
def churn(i):
    n = 0
    while time.time() < end:
        try:
            rid = ram.write("st", "h%d" % (n % 4), "k%d.%d" % (i, n % 8), {"n": n}); ok["write"] += 1
            ram.read("st", "h%d" % (n % 4)); ok["read"] += 1
            ram.remove(rid); ok["remove"] += 1
        except Exception as e: errs["%s" % e] += 1
        n += 1
ts = [threading.Thread(target=held, args=(i,)) for i in range(4)] + [threading.Thread(target=churn, args=(i,)) for i in range(4)]
[t.start() for t in ts]; [t.join() for t in ts]
print("ok", dict(ok)); print("errors", dict(errs))
