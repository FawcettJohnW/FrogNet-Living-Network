# termdrive.py HOST:PORT TARGET -- drive one browser-terminal session as the page will: login, command, logout
import base64, json, sys, time, uuid
sys.path.insert(0, "/opt/fdf/lib/python"); import fdfram
ram = fdfram.Ram(sys.argv[1]); T = sys.argv[2]; S = uuid.uuid4().hex[:12]; seq = 0; last = 0; screen = ""
def send(bag):
    global seq; bag["s"] = seq; ram.write("term", T, "%s.%d" % (S, seq % 256), bag); seq += 1
def until(text, limit=10):
    global last, screen; t0 = time.time()
    while text not in screen:
        if time.time() - t0 > limit: raise SystemExit("TIMEOUT waiting for %r; screen tail: %r" % (text, screen[-200:]))
        for c in sorted(ram.read("termout", S, after=last, wait_s=5), key=lambda c: c["id"]):
            last = c["id"]
            if "d" in c["bag"]: screen += base64.b64decode(c["bag"]["d"]).decode(errors="replace")
            if c["bag"].get("x"): screen += "\n<<END %s>>" % c["bag"].get("why"); 
    return time.time() - t0
t = time.time(); send({"open": 1, "cols": 100, "rows": 30}); print("login prompt  %.3fs" % until("login:"))
send({"d": base64.b64encode(b"frog\r").decode()}); print("password      %.3fs" % until("assword"))
send({"d": base64.b64encode(b"frogpass\r").decode()}); print("shell         %.3fs" % until("$ "))
t0 = time.time(); send({"d": base64.b64encode(b"echo hello-$((6*7))\r").decode()}); until("hello-42\r\n"); print("command echo  %.3fs" % (time.time()-t0))
send({"r": [120, 40]}); send({"d": base64.b64encode(b"stty size\r").decode()}); until("40 120"); print("resize ok")
send({"d": base64.b64encode(b"exit\r").decode()}); until("<<END"); print("end:", screen[screen.index("<<END"):])
