#!/bin/bash
# build_arm64_member.sh -- [ARM64_MEMBER_V1] the member tools for aarch64 Linux (a Pi, an ARM node): fdf-client,
# fdf-participants, fdf-watch, static (glibc, lz4 and OpenSSL's libcrypto inside), cross-built on x86_64.
# Run after tools/build.sh (it makes build/platform). Needs: g++-aarch64-linux-gnu (apt); network access to github.com
# for OpenSSL 3.0.13 and lz4. Output: build/arm64/{fdf-client,fdf-participants,fdf-watch}. Checked under
# qemu-aarch64-static: joins, listed alive, the watch sees the join and the leave.
set -eu; cd "$(dirname "$0")/.."; A=build/arm64; mkdir -p $A/o
[ -d $A/openssl-3.0.13 ] || { curl -sSL https://github.com/openssl/openssl/releases/download/openssl-3.0.13/openssl-3.0.13.tar.gz | tar xz -C $A; }
[ -f $A/openssl-3.0.13/libcrypto.a ] || ( cd $A/openssl-3.0.13 &&
    ./Configure linux-aarch64 --cross-compile-prefix=aarch64-linux-gnu- no-shared no-tests no-asm && make -j"$(nproc)" build_libs )
[ -d $A/lz4 ] || git clone -q --depth 1 https://github.com/lz4/lz4.git $A/lz4
for f in lz4 lz4hc lz4frame xxhash; do aarch64-linux-gnu-gcc -O2 -c $A/lz4/lib/$f.c -o $A/o/$f.o; done
aarch64-linux-gnu-ar rcs $A/liblz4.a $A/o/lz4.o $A/o/lz4hc.o $A/o/lz4frame.o $A/o/xxhash.o
P=build/platform; I="-I$P/ribbit_cpp -I$A/openssl-3.0.13/include -I$A/lz4/lib"
aarch64-linux-gnu-g++ -std=c++17 -O2 -pthread $I -c $P/ribbit_cpp/frogram.cpp -o $A/frogram.o
for t in fdf_client:fdf-client fdf_participants:fdf-participants fdf_watch:fdf-watch; do
    aarch64-linux-gnu-g++ -std=c++20 -O2 -pthread -D_GNU_SOURCE $I -Isrc -static src/${t%%:*}.cpp $A/frogram.o $A/liblz4.a \
        $A/openssl-3.0.13/libcrypto.a -lresolv -o $A/${t##*:} 2>&1 | grep -v "statically linked applications requires at runtime\|in function" || true
    file $A/${t##*:} | grep -q "aarch64.*statically linked" && echo "BUILD OK: $A/${t##*:} (aarch64, static)"
done
