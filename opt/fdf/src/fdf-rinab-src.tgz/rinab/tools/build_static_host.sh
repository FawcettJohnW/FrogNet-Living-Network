#!/bin/bash
# build_static_host.sh -- [STATIC_HOST_V1] rina-host as ONE fully static binary (jemalloc, lz4, libcrypto, libstdc++,
# glibc all inside), so the RAM server runs on any x86-64 Linux regardless of its glibc: the 24.04-built dynamic one
# needs glibc 2.38 and fails on Ubuntu 22.04 (StreamingFrog: "GLIBC_2.38 not found"). Run after tools/build.sh.
# Needs libjemalloc-dev, liblz4-dev, libssl-dev (their .a files). Output: build/bin/rina-host-static
set -eu; cd "$(dirname "$0")/.."; L=/usr/lib/x86_64-linux-gnu
g++ -static -o build/bin/rina-host-static build/obj/ram_server_rina.o build/obj/rina_region.o build/obj/ctl_host.o build/obj/frogram.o \
    $L/libjemalloc.a $L/liblz4.a $L/libcrypto.a -lresolv -lpthread -ldl 2>&1 | grep -v "statically linked applications requires at runtime\|in function" || true
file build/bin/rina-host-static | grep -q "statically linked" && echo "BUILD OK: build/bin/rina-host-static (static)"
# [STATIC_TOOLS_V1] the member tools, static too: the 24.04-built fdf-client and fdf-participants need glibc 2.38.
# fdf-watch ([FDF_WATCH_V1]) is the held participant watch fdf-ls --watch and fdf-browser read. Static glibc does not
# use the system's name resolver: give these an IP address (RINA_RAM=165.232.153.144:8840), not a host name.
P=build/platform; F="-std=c++20 -O2 -pthread -Wall -Wextra -Werror -Wno-free-nonheap-object -D_GNU_SOURCE -I$P/ribbit_cpp -Isrc"
for t in fdf_client:fdf-client fdf_participants:fdf-participants fdf_watch:fdf-watch; do
    g++ $F -static src/${t%%:*}.cpp build/obj/frogram.o $L/liblz4.a $L/libcrypto.a -lresolv -o build/bin/${t##*:}-static 2>&1 \
        | grep -v "statically linked applications requires at runtime\|in function" || true
    file build/bin/${t##*:}-static | grep -q "statically linked" && echo "BUILD OK: build/bin/${t##*:}-static (static)"
done
