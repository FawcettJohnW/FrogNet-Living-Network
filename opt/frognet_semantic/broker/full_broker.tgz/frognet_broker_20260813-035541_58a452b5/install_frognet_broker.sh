#!/bin/bash
# =============================================================================
# install_frognet_broker.sh — install the FrogNet Tunnel Broker v4
#
# Runs from the root of an extracted bundle built by
# build_frognet_broker_bundle.sh. Run as root on the broker host.
#
#   sudo ./install_frognet_broker.sh [--port N] [--webroot DIR]
#                                    [--no-console] [--no-packages] [--dry-run]
#
# Dependencies are installed or brought current with apt (the named set only,
# never a blanket upgrade). --no-packages skips apt entirely and verifies the
# same requirements, for an air-gapped or hand-managed box.
#
#
# The web half is the BROKER CONSOLE ONLY: pond_admin.html, its PHP backend,
# the gate library, and a gate config this script writes. It installs those
# four files by name and leaves the rest of the docroot alone — the marketing
# site sharing that directory is a separate artifact.
#
# It does not interrogate you. Everything is a flag or an environment
# variable, every effective setting is printed before anything is written,
# and every default is read off the box (existing drop-in, existing token,
# existing DB) rather than assumed.
#
# IDEMPOTENT. Re-running upgrades in place:
#   - the SQLite DB is backed up and never deleted or reinitialised
#   - the admin token is read from the existing file, or from the DB, and
#     is only minted if neither exists
#   - replaced units and drop-ins are kept as .bak-<stamp> rollback material
#
# set -euo pipefail per DOCTRINE.txt WORKING RULES: nothing in this file
# discards stderr or forces a success status. (The bare >/dev/null on
# "command -v" discards stdout only; the exit status is what the || acts on.)
# =============================================================================

set -euo pipefail
trap 'echo "FATAL: install_frognet_broker.sh line $LINENO exited $?" >&2; exit 1' ERR

TS()  { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
log() { echo "$(TS) $*"; }
die() { echo "FATAL: $*" >&2; exit 1; }

BUNDLE="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
STAMP="$(date -u +%Y%m%d-%H%M%S)"

BROKER_DIR="/opt/frognet_broker_v4"
VENV="$BROKER_DIR/venv"
STATE_DIR="/var/lib/frognet_broker_v4"
DB_PATH="$STATE_DIR/broker.db"
ETC_DIR="/etc/frognet"
TOKEN_FILE="$ETC_DIR/admin_token_v4.conf"
UNIT="frognet-broker-v4"
UNIT_DIR="/etc/systemd/system"
DROPIN_DIR="$UNIT_DIR/${UNIT}.service.d"
BACKUP_DIR="/var/backups/frognet"
SPOOL_ROOT="${FROGNET_GATE_SPOOL:-/var/spool/frognet_gate}"

PORT=""
WEBROOT="${FROGNET_WEBROOT:-/var/www/html}"
DO_WEB=1
DRY_RUN=0
DO_PACKAGES=1

while [[ $# -gt 0 ]]; do
    case "$1" in
        --port)    PORT="$2"; shift 2 ;;
        --webroot) WEBROOT="$2"; shift 2 ;;
        --no-console) DO_WEB=0; shift ;;
        --no-packages) DO_PACKAGES=0; shift ;;
        --dry-run) DRY_RUN=1; shift ;;
        -h|--help) sed -n '2,26p' "$0"; exit 0 ;;
        *) die "unknown argument: $1" ;;
    esac
done

# ---------------------------------------------------------------------------
# Preflight. Everything that could stop the install, before anything is written.
# ---------------------------------------------------------------------------

log "=== Preflight"

[[ $EUID -eq 0 ]] || die "must run as root (the broker builds wg interfaces, netns and iptables rules)"

for f in BUNDLE_ID MANIFEST.sha256 requirements.txt PYTHON_VERSION payload; do
    [[ -e "$BUNDLE/$f" ]] || die "not a bundle root: $BUNDLE/$f missing"
done
BUNDLE_ID="$(cat "$BUNDLE/BUNDLE_ID")"

# Checksums are reported, never enforced. The build already verified this
# bundle by extracting it back out and running every gate against the result;
# repeating that here only stops the operator from editing a file in an
# extracted bundle and running it, which is a normal thing to do.
# sha256sum -c exits 1 on any mismatch and set -e would kill the script before
# the warning below ever prints. Compare the digests ourselves instead: no
# non-zero exit to trap, and no redirection hiding anything.
CKSUM_BAD=""
while read -r want path; do
    path="${path#\*}"
    [[ -f "$BUNDLE/$path" ]] || { CKSUM_BAD+="$path(missing) "; continue; }
    have="$( cd "$BUNDLE" && sha256sum "$path" | cut -d' ' -f1 )"
    [[ "$have" == "$want" ]] || CKSUM_BAD+="$path "
done < "$BUNDLE/MANIFEST.sha256"
if [[ -n "${CKSUM_BAD// /}" ]]; then
    log "bundle       $BUNDLE_ID (MODIFIED since build: $CKSUM_BAD)"
else
    log "bundle       $BUNDLE_ID (checksums match)"
fi

command -v systemctl >/dev/null || die "no systemctl; this ships a systemd service"

# ---------------------------------------------------------------------------
# Dependencies.
#
# The named set only. No "apt-get upgrade" and no "dist-upgrade": this runs on
# a live broker, and a blanket upgrade is an unbounded change to a box whose
# job is holding tunnels up. "apt-get install" already pulls an outdated
# package forward, which is what "up to date" needs to mean here.
#
#   python3-venv     python3 -m venv fails without it on Debian/Ubuntu, and
#                    the failure is at ensurepip, well after it looks like it
#                    is working
#   sqlite3          the CLI, for the .backup before an upgrade and the token
#                    read out of admin_config. The python module is built in;
#                    this package is not
#   iproute2         ip          } broker_namespace_v4 drives all three to
#   iptables         iptables    } build namespaces, veths and DNAT rules
#   wireguard-tools  wg          }
#   curl             bootstrap and the postflight API check
#   ca-certificates  pip talks to PyPI over TLS to build the venv
#
# --no-packages skips every apt call and only verifies. The verification below
# is the same either way, so a skipped install cannot hide a missing binary.
# ---------------------------------------------------------------------------

PYMM="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
# BOTH venv packages. python3-venv is a metapackage; the bundled pip wheel that
# venv creation actually consumes lives in the versioned python<M.m>-venv. With
# only the metapackage, `python3 -m venv` exits 0 and produces no pip.
APT_PKGS=(python3-venv "python${PYMM}-venv" sqlite3 iproute2 iptables wireguard-tools curl ca-certificates)

if ((DO_PACKAGES)); then
    if ! command -v apt-get >/dev/null; then
        die "no apt-get on this host.
  Package handling is implemented for apt only. Install these yourself and
  re-run with --no-packages: ${APT_PKGS[*]}"
    fi

    log "=== Dependencies"

    # NEEDRESTART_MODE=l: list services that want restarting, restart none.
    # apt deciding on its own to bounce something on a live broker is not a
    # thing this script will cause.
    export DEBIAN_FRONTEND=noninteractive
    export NEEDRESTART_MODE=l

    # A broken third-party repo makes update exit non-zero. That is not by
    # itself a reason to abort: it only matters if something is actually
    # missing, and the install below fails loudly in that case. Reported
    # either way, because a stale cache is worth knowing about.
    APT_UPDATE_RC=0
    apt-get update -qq || APT_UPDATE_RC=$?
    if [[ $APT_UPDATE_RC -ne 0 ]]; then
        log "apt-get update exited $APT_UPDATE_RC (a repo is unhappy). Continuing:"
        log "  it only blocks if a package is genuinely missing, and the install"
        log "  below will say so."
    fi

    # What would change, before changing it. --dry-run prints Inst/Conf lines.
    APT_PLAN="$(apt-get install --dry-run -qq "${APT_PKGS[@]}" | sed -n 's/^Inst \([^ ]*\).*/\1/p' | tr '\n' ' ')"
    if [[ -z "${APT_PLAN// /}" ]]; then
        log "packages     all present and current: ${APT_PKGS[*]}"
    else
        log "packages     would install/upgrade: $APT_PLAN"
        if ((DRY_RUN)); then
            # This stage sits in preflight, ahead of the --dry-run stop below,
            # so it has to honour the flag itself. --dry-run means nothing is
            # written, and installing packages is writing.
            log "packages     --dry-run: apt not run"
        else
            # --force-confold: keep any config file already on the box. An
            # installer is not the place to replace a config someone tuned.
            apt-get install -y -qq -o Dpkg::Options::=--force-confold "${APT_PKGS[@]}"
            log "packages     done"
        fi
    fi
else
    log "packages     --no-packages: apt not run; verifying only"
fi

# Verification, and it runs whether or not apt did. This is the gate; the apt
# stage above is just a convenience for getting past it.
MISSING=()
for b in python3 ip iptables wg sqlite3 curl; do
    command -v "$b" >/dev/null || MISSING+=("$b")
done
# python3-venv ships no binary. ensurepip is what actually fails without it.
# Not just "import ensurepip": that module ships in the metapackage while the
# bundled pip wheel it installs from ships in python3N.N-venv. Check for the
# wheel itself, which is what venv creation actually consumes.
if ! python3 -c 'import ensurepip, venv' >/dev/null; then
    MISSING+=("python3 -m venv (package python3-venv)")
elif ! python3 -c 'import ensurepip,sys; sys.exit(0 if ensurepip._get_packages() else 1)' >/dev/null; then
    MISSING+=("ensurepip's bundled pip wheel (package python${PYMM}-venv)")
fi

if [[ ${#MISSING[@]} -gt 0 ]]; then
    echo "Missing dependencies:" >&2
    for m in "${MISSING[@]}"; do echo "    - $m" >&2; done
    if ((DRY_RUN)) && ((DO_PACKAGES)); then
        log "deps         --dry-run: apt was skipped, so these are expected;"
        log "             a real run installs them from the plan above"
    elif ((DO_PACKAGES)); then
        die "apt ran and these are still missing. Fix the repo or install them by hand."
    else
        die "--no-packages was given, so nothing was installed.
  Install these and re-run: ${APT_PKGS[*]}"
    fi
else
    log "deps         verified: python3 ip iptables wg sqlite3 curl, venv module"
fi

if ((DO_WEB)) && [[ ! -d "$BUNDLE/payload/www" ]]; then
    DO_WEB=0
    WEB_NOTE=" (bundle built --no-console, no console payload)"
fi
WEB_NOTE="${WEB_NOTE:-}"

PYVER_WANT="$(cat "$BUNDLE/PYTHON_VERSION")"
PYVER_HAVE="$(python3 -c 'import platform; print(platform.python_version())')"
log "python       have $PYVER_HAVE, bundle built against $PYVER_WANT"
if [[ "${PYVER_HAVE%.*}" != "${PYVER_WANT%.*}" ]]; then
    log "             minor versions differ; the venv is rebuilt from source pins, so this is"
    log "             legal, but uvloop/httptools/pydantic-core wheels will be different builds"
fi

# The bind port: the box's current setting wins unless --port says otherwise.
CURRENT_PORT=""
if [[ -f "$DROPIN_DIR/listen.conf" ]]; then
    CURRENT_PORT="$(sed -n 's|.*--port[= ]\([0-9]\{1,\}\).*|\1|p' "$DROPIN_DIR/listen.conf" | head -1)"
fi
if [[ -z "$PORT" ]]; then
    if [[ -n "$CURRENT_PORT" ]]; then
        PORT="$CURRENT_PORT"
    else
        PORT=18257
    fi
fi
[[ "$PORT" =~ ^[0-9]+$ ]] || die "--port must be numeric, got: $PORT"

# Port ownership. The broker binds 0.0.0.0:$PORT directly. If Apache or
# anything else already holds it, say so now rather than after the unit is
# installed and restart-looping.
PORT_OWNER=""
if command -v ss >/dev/null; then
    PORT_OWNER="$(ss -tlnpH "sport = :$PORT" | sed 's/.*users:((\"\([^\"]*\)\".*/\1/' | sort -u | tr '\n' ' ')"
fi
if [[ -n "${PORT_OWNER// /}" && "$PORT_OWNER" != *"uvicorn"* && "$PORT_OWNER" != *"python"* ]]; then
    log "NOTE         port $PORT is currently held by: $PORT_OWNER"
    log "             the broker binds it directly. If that is a conflict the"
    log "             bind fails at start and postflight reports it."
fi

echo
log "broker dir   $BROKER_DIR"
log "state dir    $STATE_DIR (db: $DB_PATH)"
log "bind         0.0.0.0:$PORT${CURRENT_PORT:+  (current: $CURRENT_PORT)}"
log "console      $( ((DO_WEB)) && echo "$WEBROOT (4 files)" || echo "skipped${WEB_NOTE:- (--no-console)}" )"
log "mode         $( [[ -f "$DB_PATH" ]] && echo "upgrade (existing database found)" || echo "fresh install" )"
echo

if ((DRY_RUN)); then
    log "--dry-run: nothing written. Stopping here."
    exit 0
fi

# ---------------------------------------------------------------------------
# Backup
# ---------------------------------------------------------------------------

log "=== Backup"
mkdir -p "$BACKUP_DIR" "$ETC_DIR"

if [[ -f "$DB_PATH" ]]; then
    # .backup is a consistent copy of a live SQLite file; cp is not.
    sqlite3 "$DB_PATH" ".backup '$BACKUP_DIR/broker.db.$STAMP'"
    log "database      -> $BACKUP_DIR/broker.db.$STAMP"
fi
for f in "$UNIT_DIR/${UNIT}.service" "$DROPIN_DIR/listen.conf" "$DROPIN_DIR/wgports.conf"; do
    if [[ -f "$f" ]]; then
        cp -p "$f" "${f}.bak-${STAMP}"
        log "rollback      -> ${f}.bak-${STAMP}"
    fi
done

# ---------------------------------------------------------------------------
# Python environment
# ---------------------------------------------------------------------------

log "=== Python environment"
mkdir -p "$BROKER_DIR"

if [[ -d "$VENV" ]]; then
    VENV_PY="$(sed -n 's/^version = //p' "$VENV/pyvenv.cfg")"
    if [[ "${VENV_PY%.*}" != "${PYVER_HAVE%.*}" ]]; then
        log "existing venv built against $VENV_PY, interpreter is $PYVER_HAVE — rebuilding"
        mv "$VENV" "${VENV}.bak-${STAMP}"
    fi
fi
if [[ ! -d "$VENV" ]]; then
    VENV_OUT="$(python3 -m venv "$VENV" 2>&1)" || {
        echo "$VENV_OUT" >&2
        die "python3 -m venv failed"
    }
    [[ -n "$VENV_OUT" ]] && log "venv          $VENV_OUT"
fi

# python3 -m venv can exit 0 and still leave no pip: Debian ships the ensurepip
# MODULE in python3-venv (a metapackage) but the bundled pip wheel lives in the
# versioned python3N.N-venv package. So "import ensurepip" succeeding in
# preflight is not proof pip can be bootstrapped — this is.
#
# Probe with `python3 -m pip`, never a bin/pip file test: ensurepip installs
# console scripts named pip3 and pip3.N, and does NOT always create a bare
# `pip`. The module invocation works regardless of which names exist.
PIP=("$VENV/bin/python3" -m pip)
if ! "${PIP[@]}" --version >/dev/null 2>&-; then
    log "venv          no pip after venv creation; bootstrapping with ensurepip"
    EP_RC=0
    EP_OUT="$("$VENV/bin/python3" -m ensurepip --upgrade 2>&1)" || EP_RC=$?
    if ! "${PIP[@]}" --version >/dev/null; then
        log "venv          ensurepip exited $EP_RC"
        echo "$EP_OUT" >&2
        die "the venv has no pip and ensurepip could not supply one.
  The bundled pip wheel is in the versioned package, not the metapackage:
    apt install python${PYMM}-venv
  Then re-run. (python3-venv alone is not enough on Debian/Ubuntu.)"
    fi
    log "venv          pip bootstrapped via ensurepip"
fi

"${PIP[@]}" install --quiet --disable-pip-version-check --upgrade pip
"${PIP[@]}" install --quiet --disable-pip-version-check -r "$BUNDLE/requirements.txt"
# Prove the pins took rather than trusting pip's exit code alone.
"${PIP[@]}" install --quiet --disable-pip-version-check --dry-run \
    -r "$BUNDLE/requirements.txt" > /dev/null
log "venv          $("$VENV/bin/python3" -c 'import fastapi,uvicorn,pydantic; print("fastapi",fastapi.__version__,"uvicorn",uvicorn.__version__,"pydantic",pydantic.VERSION)')"

# ---------------------------------------------------------------------------
# Code
# ---------------------------------------------------------------------------

log "=== Code"

install -d -m 0755 "$BROKER_DIR/tools" "$BROKER_DIR/docs"
install -m 0644 "$BUNDLE/payload/opt/frognet_broker_v4/"*.py       "$BROKER_DIR/"
install -m 0755 "$BUNDLE/payload/opt/frognet_broker_v4/tools/"*    "$BROKER_DIR/tools/"
install -m 0644 "$BUNDLE/payload/opt/frognet_broker_v4/docs/"*     "$BROKER_DIR/docs/"
log "broker        $BROKER_DIR ($(ls "$BUNDLE/payload/opt/frognet_broker_v4/"*.py | wc -l) modules, $(ls "$BUNDLE/payload/opt/frognet_broker_v4/tools/" | wc -l) tools)"

# A stale .pyc shadowing an updated module is the recurring "the logs show old
# code" trap. The unit sets PYTHONDONTWRITEBYTECODE, but clear what is there.
find "$BROKER_DIR" -path "$VENV" -prune -o -name '__pycache__' -type d -print0 | xargs -0 -r rm -rf
find "$BROKER_DIR" -path "$VENV" -prune -o -name '*.pyc' -type f -print0 | xargs -0 -r rm -f

# Every other install target in this script gets an `install -d` first; this
# one did not, and `install` with a nonexistent directory treats the trailing
# path as a FILENAME, which is why the failure reads "cannot create regular
# file '/usr/local/bin/'". If the path exists as a non-directory, the mkdir
# below fails loudly and correctly — that is a real problem with the host.
install -d -m 0755 /usr/local/bin
install -m 0755 "$BUNDLE/payload/usr/local/bin/"* /usr/local/bin/
log "operator CLI  /usr/local/bin/frognet-pond"

# ---------------------------------------------------------------------------
# Web root
# ---------------------------------------------------------------------------

if ((DO_WEB)); then
    log "=== Broker console"
    if [[ ! -d "$WEBROOT" ]]; then
        log "webroot      $WEBROOT does not exist; creating it"
        install -d -m 0755 "$WEBROOT"
    fi

    # PHP is not installed by this script: choosing libapache2-mod-php vs
    # php-fpm is a decision about a web tier this installer was not told
    # about. If it is absent the four files still land correctly and the
    # console is inert until PHP is there, so this reports and moves on.
    if ! command -v php >/dev/null && ! compgen -G "/etc/apache2/mods-enabled/php*.conf" >/dev/null; then
        log "NOTE         no PHP detected; the console is PHP and will not execute"
        log "             until it is installed (apache2: libapache2-mod-php,"
        log "             nginx: php-fpm). Files are installed regardless."
    fi

    # Three files, named. This does not touch the rest of the docroot: the
    # marketing site that shares it is a separate artifact on its own release
    # cycle, and the broker install has no business overwriting it.
    for f in pond_admin.html frognet_broker_admin_v4.php frognet_gate_lib.php; do
        install -m 0644 "$BUNDLE/payload/www/$f" "$WEBROOT/$f"
    done

    # Written here, not shipped, per its own header. The spool root is this
    # box's, not whatever the build snapshot happened to contain.
    cat > "$WEBROOT/frognet_gate_config.php" <<EOF
<?php
/**
 * Written by install_frognet_broker.sh at $(TS) from bundle $BUNDLE_ID.
 * Contains NO secrets — only the path of the directory this tier may write
 * into. The credential it does not have is the whole point.
 */
define('FNGATE_SPOOL_ROOT', '$SPOOL_ROOT');
define('FNGATE_TIMEOUT_SEC', 60.0);
EOF
    chmod 0644 "$WEBROOT/frognet_gate_config.php"

    # The console writes an envelope into $domain/req and waits for $domain/resp.
    # Group-writable by the web user; the gatekeeper owns the other side.
    install -d -m 0755 "$SPOOL_ROOT"
    install -d -m 0770 "$SPOOL_ROOT/admin" "$SPOOL_ROOT/admin/req" "$SPOOL_ROOT/admin/resp"
    if getent group www-data > /dev/null; then
        chown -R root:www-data "$SPOOL_ROOT/admin"
        chown root:www-data "$WEBROOT/pond_admin.html" \
                            "$WEBROOT/frognet_broker_admin_v4.php" \
                            "$WEBROOT/frognet_gate_lib.php" \
                            "$WEBROOT/frognet_gate_config.php"
    fi

    log "console       $WEBROOT/pond_admin.html (+ 3 backing files)"
    log "spool         $SPOOL_ROOT/admin/{req,resp}"
    if [[ ! -x /opt/frognet_gate/gatekeeper/frognet_gatekeeper.py ]]; then
        log "              NOTE: no gatekeeper at /opt/frognet_gate/gatekeeper/. The"
        log "              console will queue requests and time out at 60s until one"
        log "              is running on the private side of this spool. That block is"
        log "              the design, not a fault — the PHP holds no credential."
    fi
fi

# ---------------------------------------------------------------------------
# systemd
# ---------------------------------------------------------------------------

log "=== Service"

install -m 0644 "$BUNDLE/payload/etc/systemd/system/${UNIT}.service" "$UNIT_DIR/${UNIT}.service"
install -d -m 0755 "$DROPIN_DIR"
install -m 0644 "$BUNDLE/payload/etc/systemd/system/${UNIT}.service.d/wgports.conf" \
                "$DROPIN_DIR/wgports.conf"

# The listen drop-in is written here, not shipped, because the shipped one on
# the snapshot carried a live FROGNET_ADMIN_TOKEN. It carries the bind only.
# The broker loads the token from admin_config in the DB at startup when the
# environment does not set it.
cat > "$DROPIN_DIR/listen.conf" <<EOF
# Written by install_frognet_broker.sh at $(TS) from bundle $BUNDLE_ID.
# Bind only. No credential: the broker reads admin_token from its database
# at startup when FROGNET_ADMIN_TOKEN is unset.
[Service]
Environment="FROGNET_BROKER_HOST=0.0.0.0"
Environment="FROGNET_BROKER_PORT=$PORT"
ExecStart=
ExecStart=$VENV/bin/uvicorn frognet_broker_v4:app --host 0.0.0.0 --port $PORT --log-level info
EOF
log "unit          $UNIT_DIR/${UNIT}.service"
log "drop-ins      listen.conf (0.0.0.0:$PORT), wgports.conf ($(sed -n 's/.*PORT_BASE=\([0-9]*\).*/\1/p' "$DROPIN_DIR/wgports.conf")-$(sed -n 's/.*PORT_MAX=\([0-9]*\).*/\1/p' "$DROPIN_DIR/wgports.conf"))"

systemctl daemon-reload
systemctl enable "$UNIT"
systemctl restart "$UNIT"

# ---------------------------------------------------------------------------
# Firewall
# ---------------------------------------------------------------------------

if command -v ufw >/dev/null; then
    log "=== Firewall"
    if ufw status | head -1 | grep -q "Status: active"; then
        if ufw status | grep -qE "^${PORT}(/tcp)?[[:space:]]+ALLOW"; then
            log "ufw           $PORT/tcp already allowed"
        else
            ufw allow "${PORT}/tcp"
            log "ufw           opened $PORT/tcp"
        fi
        WG_BASE="$(sed -n 's/.*PORT_BASE=\([0-9]*\).*/\1/p' "$DROPIN_DIR/wgports.conf")"
        WG_MAX="$(sed -n 's/.*PORT_MAX=\([0-9]*\).*/\1/p' "$DROPIN_DIR/wgports.conf")"
        if ufw status | grep -qE "^${WG_BASE}:${WG_MAX}/udp[[:space:]]+ALLOW"; then
            log "ufw           ${WG_BASE}:${WG_MAX}/udp already allowed"
        else
            ufw allow "${WG_BASE}:${WG_MAX}/udp"
            log "ufw           opened ${WG_BASE}:${WG_MAX}/udp (tunnel endpoints)"
        fi
    else
        log "ufw           installed but inactive; no rules added"
    fi
fi

# ---------------------------------------------------------------------------
# Admin token
# ---------------------------------------------------------------------------

log "=== Admin token"

for i in $(seq 1 30); do
    if ss -tlnH "sport = :$PORT" | grep -q . ; then break; fi
    if ! systemctl is-active --quiet "$UNIT"; then
        journalctl -u "$UNIT" -n 40 --no-pager
        die "broker died during startup"
    fi
    sleep 1
done
ss -tlnH "sport = :$PORT" | grep -q . || {
    journalctl -u "$UNIT" -n 40 --no-pager
    die "broker never bound $PORT after 30s"
}

ADMIN_TOKEN=""
if [[ -f "$TOKEN_FILE" ]]; then
    ADMIN_TOKEN="$(cat "$TOKEN_FILE")"
    log "token         reused from $TOKEN_FILE"
elif [[ -f "$DB_PATH" ]]; then
    ADMIN_TOKEN="$(sqlite3 "$DB_PATH" "SELECT value FROM admin_config WHERE key='admin_token';")"
    if [[ -n "$ADMIN_TOKEN" ]]; then
        log "token         recovered from the database"
    fi
fi

if [[ -z "$ADMIN_TOKEN" ]]; then
    BOOTSTRAP="$(curl -sf -X POST "http://127.0.0.1:$PORT/api/v4/bootstrap" -H 'Content-Type: application/json')"
    ADMIN_TOKEN="$(printf '%s' "$BOOTSTRAP" | python3 -c 'import sys,json; print(json.load(sys.stdin)["admin_token"])')"
    log "token         minted via /api/v4/bootstrap"
fi
[[ -n "$ADMIN_TOKEN" ]] || die "no admin token after bootstrap"

umask 077
printf '%s\n' "$ADMIN_TOKEN" > "$TOKEN_FILE"
umask 022
chmod 0640 "$TOKEN_FILE"
if getent group www-data > /dev/null; then
    chown root:www-data "$TOKEN_FILE"
else
    chown root:root "$TOKEN_FILE"
fi
log "token         $TOKEN_FILE ($(stat -c '%U:%G %a' "$TOKEN_FILE"))"

# ---------------------------------------------------------------------------
# Postflight. The install is not done until the service answers.
# ---------------------------------------------------------------------------

echo
log "=== Postflight"

systemctl is-active --quiet "$UNIT" || {
    journalctl -u "$UNIT" -n 40 --no-pager
    die "$UNIT is not active"
}
log "service       active, $(systemctl show -p MainPID --value "$UNIT") pid"

LISTEN="$(ss -tlnH "sport = :$PORT" | awk '{print $4}' | tr '\n' ' ')"
log "listening     $LISTEN"

CODE="$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 \
        -H "Authorization: Bearer $ADMIN_TOKEN" "http://127.0.0.1:$PORT/api/v4/ponds")"
[[ "$CODE" == "200" ]] || {
    journalctl -u "$UNIT" -n 40 --no-pager
    die "GET /api/v4/ponds returned $CODE, expected 200"
}
log "api           GET /api/v4/ponds -> 200"

PONDS="$(curl -s --max-time 15 -H "Authorization: Bearer $ADMIN_TOKEN" \
         "http://127.0.0.1:$PORT/api/v4/ponds" \
         | python3 -c 'import sys,json; d=json.load(sys.stdin); print(len(d["ponds"]) if isinstance(d,dict) and "ponds" in d else len(d))')"
log "data          $PONDS pond(s) visible; database preserved at $DB_PATH"

echo
log "installed: $BUNDLE_ID"
echo
echo "  frognet-pond list                         (FROGNET_GATE_URL=http://127.0.0.1:$PORT)"
echo "  journalctl -u $UNIT -f"
echo "  rollback: units at *.bak-${STAMP}, database at $BACKUP_DIR/broker.db.$STAMP"
echo
