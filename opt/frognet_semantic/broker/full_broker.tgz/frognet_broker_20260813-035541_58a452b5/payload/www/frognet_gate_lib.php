<?php
/**
 * frognet_gate_lib.php — [AIRGAP_PHPCLIENT_V1] the web tier's entire capability.
 *
 * This file is the complete list of things the internet-facing process can do:
 * write a request file, wait for a response file, read it, and give up after a
 * deadline. There is no socket call, no database handle, no shell, no
 * credential at rest. If this file were replaced wholesale by an attacker, the
 * worst it could do is submit well-formed requests that the gatekeeper would
 * validate and authorise exactly as it validates ours.
 *
 * THE BLOCK IS INTENTIONAL. submit_and_wait() holds the HTTP request open until
 * the gatekeeper answers. If the gatekeeper is stopped, wedged, or has not been
 * installed, the call times out and returns 504. That is the correct outcome
 * and it is reported as an error, never as a success and never as an empty
 * result — a gate that fails open is not a gate.
 *
 * The response body is echoed VERBATIM, exactly as the broker rendered it, so
 * every existing client sees the bytes it sees today.
 */

declare(strict_types=1);

define('FNGATE_MAGIC', 'FNGATE1');

/**
 * The installer writes frognet_gate_config.php next to this file with the
 * spool root it chose. Defining the constants beforehand also lets the oracles
 * point the whole tier at a temp directory, which is the only way to test the
 * timeout path without stopping a production service.
 */
if (is_file(__DIR__ . '/frognet_gate_config.php')) {
    require_once __DIR__ . '/frognet_gate_config.php';
}

/** Where the spool lives. The gatekeeper reads its own copy of this path from
 *  a root-only config; the two only need to name the same directory. */
if (!defined('FNGATE_SPOOL_ROOT')) {
    define('FNGATE_SPOOL_ROOT', '/var/spool/frognet_gate');
}

/** Default wait. Tunnel creation shells out to wg and iptables and can take
 *  several seconds on a cold pond, so this is generous on purpose. */
if (!defined('FNGATE_TIMEOUT_SEC')) {
    define('FNGATE_TIMEOUT_SEC', 60.0);
}

/** Polling cadence. Starts tight so a fast action feels immediate, then backs
 *  off so a slow one does not spin a core. */
const FNGATE_POLL_START_US = 2000;
const FNGATE_POLL_MAX_US   = 25000;

const FNGATE_MAX_BODY_BYTES = 96 * 1024;


function fngate_new_id(): string
{
    return bin2hex(random_bytes(16));
}

function fngate_valid_id(string $id): bool
{
    return (bool) preg_match('/^[0-9a-f]{32}$/', $id);
}

function fngate_fail(int $status, string $message, array $extra = []): void
{
    http_response_code($status);
    header('Content-Type: application/json');
    header('Cache-Control: no-store');
    echo json_encode(array_merge(
        ['ok' => false, 'error' => $message], $extra
    )), "\n";
    exit;
}

/** Everything the gatekeeper is told about the caller. Recorded, never trusted. */
function fngate_client_info(): array
{
    return [
        'ip'  => (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
        'ua'  => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 256),
        'fwd' => substr((string) ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''), 0, 256),
    ];
}

/**
 * Read the caller's credential out of the request.
 *
 * A bearer token is relayed as the CALLER's credential — we do not hold one of
 * our own and we never compare it here. The gatekeeper does that check against
 * a file this process cannot read. A session token is the capability the
 * gatekeeper minted at login.
 */
function fngate_auth_from_request(): array
{
    $header = (string) ($_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (stripos($header, 'Bearer ') === 0) {
        return ['kind' => 'bearer', 'value' => substr($header, 7)];
    }
    if (!empty($_SESSION['fngate_session'])) {
        return ['kind' => 'session', 'value' => (string) $_SESSION['fngate_session']];
    }
    return ['kind' => 'none', 'value' => ''];
}

/**
 * Write the request file atomically: temp name in the same directory, then
 * rename. The gatekeeper must never observe a half-written envelope.
 */
function fngate_submit(string $domain, string $action, array $params,
                       array $auth, string $id): void
{
    $dir = FNGATE_SPOOL_ROOT . '/' . $domain . '/req';
    $envelope = [
        'gate'   => FNGATE_MAGIC,
        'id'     => $id,
        'ts'     => microtime(true),
        'domain' => $domain,
        'action' => $action,
        'params' => (object) $params,
        'auth'   => $auth,
        'client' => fngate_client_info(),
    ];
    $blob = json_encode($envelope, JSON_UNESCAPED_SLASHES);
    if ($blob === false) {
        fngate_fail(400, 'request could not be encoded');
    }
    if (strlen($blob) > FNGATE_MAX_BODY_BYTES) {
        fngate_fail(413, 'request too large');
    }

    $tmp = $dir . '/.tmp-' . bin2hex(random_bytes(8)) . '.json';
    $written = file_put_contents($tmp, $blob, LOCK_EX);
    if ($written === false || $written !== strlen($blob)) {
        if (is_file($tmp)) {
            unlink($tmp);
        }
        fngate_fail(503, 'cannot queue request: the request spool is not writable');
    }
    chmod($tmp, 0640);
    if (!rename($tmp, $dir . '/' . $id . '.json')) {
        unlink($tmp);
        fngate_fail(503, 'cannot queue request: rename into the spool failed');
    }
}

/**
 * Wait for the gatekeeper's answer.
 *
 * Returns the decoded response envelope, or null on timeout. A timeout means
 * the caller stopped waiting — it does NOT mean the action did not run. That
 * distinction is reported to the caller rather than papered over, and the
 * response file stays on disk so the result can be fetched by id afterwards.
 */
function fngate_wait(string $domain, string $id, float $timeout): ?array
{
    $path = FNGATE_SPOOL_ROOT . '/' . $domain . '/resp/' . $id . '.json';
    $deadline = microtime(true) + $timeout;
    $sleep = FNGATE_POLL_START_US;

    while (microtime(true) < $deadline) {
        clearstatcache(true, $path);
        if (is_file($path)) {
            $blob = file_get_contents($path, false, null, 0, FNGATE_MAX_BODY_BYTES + 1);
            if ($blob !== false && strlen($blob) <= FNGATE_MAX_BODY_BYTES) {
                $env = json_decode($blob, true);
                if (is_array($env)
                    && ($env['gate'] ?? '') === FNGATE_MAGIC
                    && ($env['id'] ?? '') === $id) {
                    return $env;
                }
            }
            // Present but unreadable or mismatched: keep waiting rather than
            // returning something we cannot vouch for.
        }
        usleep($sleep);
        $sleep = min($sleep * 2, FNGATE_POLL_MAX_US);
    }
    return null;
}

/** Emit a gatekeeper response envelope as the HTTP response. */
function fngate_emit(array $env): void
{
    $status = (int) ($env['status'] ?? 500);
    $body   = (string) ($env['body'] ?? '{}');
    http_response_code($status);
    header('Content-Type: application/json');
    header('Cache-Control: no-store');
    header('X-FrogNet-Gate: ' . FNGATE_MAGIC . '; id=' . ($env['id'] ?? '')
        . '; ms=' . (int) ($env['elapsed_ms'] ?? 0));
    echo $body;
    exit;
}

/**
 * The whole round trip, returning the envelope.
 *
 * Used directly by the operator front door, which has to read the minted
 * session out of the answer before deciding what to send the browser. On
 * timeout this does not return — it emits 504 and exits, because a caller that
 * received no answer must not be able to continue as though it had one.
 */
function fngate_roundtrip(string $domain, string $action, array $params,
                          ?array $auth = null, ?float $timeout = null): array
{
    $id = fngate_new_id();
    $auth = $auth ?? fngate_auth_from_request();
    $timeout = $timeout ?? FNGATE_TIMEOUT_SEC;

    fngate_submit($domain, $action, $params, $auth, $id);
    $env = fngate_wait($domain, $id, $timeout);

    if ($env === null) {
        fngate_fail(504,
            sprintf('the gatekeeper did not answer within %.0fs', $timeout),
            [
                'request_id' => $id,
                'note'       => 'the request may still execute; retrieve it '
                              . 'later with ?gate_result=' . $id,
            ]);
    }
    return $env;
}

/**
 * Round trip and emit. This is what every plain front door calls.
 */
function fngate_call(string $domain, string $action, array $params,
                     ?array $auth = null, ?float $timeout = null): void
{
    fngate_emit(fngate_roundtrip($domain, $action, $params, $auth, $timeout));
}

/**
 * Fetch a completed result by id — the other half of the timeout story.
 * Knowing the id is the capability; ids are 128 bits from the CSPRNG and the
 * response directory cannot be listed by this process.
 */
function fngate_result(string $domain, string $id): void
{
    if (!fngate_valid_id($id)) {
        fngate_fail(400, 'malformed request id');
    }
    $env = fngate_wait($domain, $id, 0.05);
    if ($env === null) {
        fngate_fail(404, 'no result for that id (not finished, or aged out)',
            ['request_id' => $id]);
    }
    fngate_emit($env);
}

/**
 * Decode a JSON request body, with a hard cap.
 *
 * Under a web SAPI the body is php://input. Under the CLI SAPI php://input is
 * always empty and the body arrives on stdin instead; the fallback exists so
 * the oracles can drive THIS file rather than a reimplementation of it. The
 * branch is unreachable under Apache — PHP_SAPI is never 'cli' there — so it
 * cannot change how a request from the network is read.
 */
function fngate_json_body(): array
{
    $stream = (PHP_SAPI === 'cli') ? 'php://stdin' : 'php://input';
    $raw = file_get_contents($stream, false, null, 0,
        FNGATE_MAX_BODY_BYTES + 1);
    if ($raw === false || $raw === '') {
        return [];
    }
    if (strlen($raw) > FNGATE_MAX_BODY_BYTES) {
        fngate_fail(413, 'request too large');
    }
    $data = json_decode($raw, true);
    if ($data === null && trim($raw) !== 'null') {
        fngate_fail(400, 'body is not valid JSON');
    }
    return is_array($data) ? $data : [];
}
