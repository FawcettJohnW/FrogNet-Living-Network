<?php
/**
 * frognet_broker_admin_v4.php — [AIRGAP_CONSOLE_V2]
 *
 * Drop-in replacement for the console backend, keeping pond_admin.html working
 * unchanged: same filename, same "?action=" shape, same action names, same JSON
 * out. The page needs no edit.
 *
 * WHAT CHANGED IS UNDERNEATH, AND IT IS THE WHOLE POINT.
 *
 * The file this replaces held two secrets in the web root: a page password
 * compiled into the source, and the path to the broker's admin token, which it
 * read and attached to every backend call it made. Anything that could read
 * that file, or run as that process, owned the pond.
 *
 * This file holds NEITHER, and cannot. It has no token, no broker address, no
 * curl handle, no database. Its entire capability is: write the request into a
 * directory, wait for an answer to appear in another one, return it. The
 * process that holds the credential and makes the call is on the other side of
 * that boundary and has no network address at all.
 *
 * THE BLOCK IS DELIBERATE. If the watcher is stopped, these calls time out and
 * report it. A gate that fails open is not a gate.
 *
 * The password is not checked here. It is relayed once, verified privately, and
 * what comes back is a session the private side minted and can expire - so a
 * compromise of this tier yields an hour-long capability, not a credential that
 * owns the pond until someone notices.
 */

declare(strict_types=1);

require_once __DIR__ . '/frognet_gate_lib.php';

const GATE_DOMAIN = 'admin';

/** Destructive verbs walk wg and iptables once per interface. Give them room;
 *  the gate's own 504 is a better error than Apache severing the connection. */
const ADMIN_TIMEOUT_SEC   = 60.0;
const DESTRUCTIVE_TIMEOUT = 300.0;

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'httponly' => true,
    'samesite' => 'Strict',
    'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
]);
session_start();

$action = (string) ($_GET['action'] ?? '');
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$input  = ($method === 'POST') ? fngate_json_body() : [];

/** The session token the private side minted, or none. */
function admin_auth(): array
{
    if (empty($_SESSION['fngate_session'])) {
        return ['kind' => 'none', 'value' => ''];
    }
    return ['kind' => 'session', 'value' => (string) $_SESSION['fngate_session']];
}

function admin_require_post(string $method): void
{
    if ($method !== 'POST') {
        fngate_fail(405, 'POST required');
    }
}

function admin_str(array $src, string $key): string
{
    $value = $src[$key] ?? '';
    return is_string($value) ? trim($value) : '';
}

/** Only send fields the caller actually supplied, so an absent field stays
 *  absent rather than arriving as an explicit null. */
function admin_present(array $src, string $key): bool
{
    return array_key_exists($key, $src) && $src[$key] !== null;
}

function admin_bool($value): bool
{
    if (is_bool($value)) { return $value; }
    if (is_int($value))  { return $value !== 0; }
    if (is_string($value)) {
        return in_array(strtolower(trim($value)), ['true','1','yes','on'], true);
    }
    return (bool) $value;
}

switch ($action) {

    // ---- auth ------------------------------------------------------------

    case 'login': {
        admin_require_post($method);
        $env = fngate_roundtrip(GATE_DOMAIN, 'login',
            ['password' => (string) ($input['password'] ?? '')],
            ['kind' => 'none', 'value' => ''], 30.0);

        $answer = json_decode((string) ($env['body'] ?? '{}'), true);
        if ((int) ($env['status'] ?? 500) !== 200 || empty($answer['session'])) {
            session_regenerate_id(true);
            unset($_SESSION['fngate_session']);
            fngate_emit($env);
        }
        // New session id on privilege change; the fixation defence is one line.
        session_regenerate_id(true);
        $_SESSION['fngate_session'] = (string) $answer['session'];
        http_response_code(200);
        header('Content-Type: application/json');
        header('Cache-Control: no-store');
        echo json_encode(['ok' => true]), "\n";
        exit;
    }

    case 'logout': {
        if (!empty($_SESSION['fngate_session'])) {
            fngate_roundtrip(GATE_DOMAIN, 'logout', [], admin_auth(), 30.0);
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        http_response_code(200);
        header('Content-Type: application/json');
        echo json_encode(['ok' => true]), "\n";
        exit;
    }

    case 'session':
        // Asked of the private side, not answered from the cookie: a session
        // that expired there must report unauthenticated here.
        fngate_call(GATE_DOMAIN, 'session', [], admin_auth(), 30.0);

    // ---- ponds -----------------------------------------------------------

    case 'ponds':
        fngate_call(GATE_DOMAIN, 'ponds', [], admin_auth(), ADMIN_TIMEOUT_SEC);

    case 'pond-status': {
        $pond = admin_str($_GET, 'pond');
        if ($pond === '') { fngate_fail(400, 'pond parameter required'); }
        fngate_call(GATE_DOMAIN, 'pond-status', ['pond' => $pond],
            admin_auth(), ADMIN_TIMEOUT_SEC);
    }

    case 'create-pond': {
        admin_require_post($method);
        $name = admin_str($input, 'name');
        if ($name === '') { fngate_fail(400, 'name is required'); }
        $params = ['name' => $name];
        if (admin_present($input, 'max_users')) {
            $params['max_users'] = (int) $input['max_users'];
        }
        if (admin_present($input, 'node_base')) {
            $params['node_base'] = admin_str($input, 'node_base');
        }
        if (admin_present($input, 'node_increment')) {
            $params['node_increment'] = (int) $input['node_increment'];
        }
        if (admin_present($input, 'password')) {
            $params['password'] = (string) $input['password'];
        }
        if (admin_present($input, 'allow_user_choruses')) {
            $params['allow_user_choruses'] = admin_bool($input['allow_user_choruses']);
        }
        fngate_call(GATE_DOMAIN, 'create-pond', $params,
            admin_auth(), ADMIN_TIMEOUT_SEC);
    }

    case 'patch-pond': {
        admin_require_post($method);
        $name = admin_str($input, 'name');
        if ($name === '') { fngate_fail(400, 'name is required'); }
        $params = ['name' => $name];
        if (admin_present($input, 'allow_user_choruses')) {
            $params['allow_user_choruses'] = admin_bool($input['allow_user_choruses']);
        }
        if (admin_present($input, 'max_users')) {
            $params['max_users'] = (int) $input['max_users'];
        }
        if (admin_present($input, 'password')) {
            $params['password'] = (string) $input['password'];
        }
        fngate_call(GATE_DOMAIN, 'patch-pond', $params,
            admin_auth(), ADMIN_TIMEOUT_SEC);
    }

    // ---- choruses --------------------------------------------------------

    case 'create-chorus': {
        admin_require_post($method);
        $pond = admin_str($input, 'pond');
        $name = admin_str($input, 'name');
        if ($pond === '' || $name === '') {
            fngate_fail(400, 'pond and name are required');
        }
        $params = ['pond' => $pond, 'name' => $name];
        if (admin_present($input, 'visible')) {
            $params['visible'] = admin_bool($input['visible']);
        }
        if (admin_present($input, 'password')) {
            $params['password'] = (string) $input['password'];
        }
        fngate_call(GATE_DOMAIN, 'create-chorus', $params,
            admin_auth(), ADMIN_TIMEOUT_SEC);
    }

    case 'remove-chorus-member': {
        admin_require_post($method);
        $params = [
            'pond'      => admin_str($input, 'pond'),
            'chorus'    => admin_str($input, 'chorus'),
            'node_name' => admin_str($input, 'node_name'),
        ];
        foreach ($params as $k => $v) {
            if ($v === '') { fngate_fail(400, 'pond, chorus, and node_name are required'); }
        }
        fngate_call(GATE_DOMAIN, 'remove-chorus-member', $params,
            admin_auth(), DESTRUCTIVE_TIMEOUT);
    }

    // ---- nodes -----------------------------------------------------------

    case 'nodes': {
        $pond = admin_str($_GET, 'pond');
        fngate_call(GATE_DOMAIN, 'nodes',
            $pond === '' ? [] : ['pond' => $pond],
            admin_auth(), ADMIN_TIMEOUT_SEC);
    }

    case 'force-deregister': {
        admin_require_post($method);
        $pubkey = admin_str($input, 'pubkey');
        if ($pubkey === '') { fngate_fail(400, 'pubkey is required'); }
        fngate_call(GATE_DOMAIN, 'force-deregister', ['pubkey' => $pubkey],
            admin_auth(), DESTRUCTIVE_TIMEOUT);
    }

    // ---- blocklist -------------------------------------------------------

    case 'blocklist':
        fngate_call(GATE_DOMAIN, 'blocklist', [], admin_auth(), ADMIN_TIMEOUT_SEC);

    case 'block-node': {
        admin_require_post($method);
        $pubkey = admin_str($input, 'pubkey');
        if ($pubkey === '') { fngate_fail(400, 'pubkey is required'); }
        $params = ['pubkey' => $pubkey];
        foreach (['node_name', 'pond_name', 'reason'] as $field) {
            if (admin_present($input, $field)) {
                $params[$field] = admin_str($input, $field);
            }
        }
        fngate_call(GATE_DOMAIN, 'block-node', $params,
            admin_auth(), DESTRUCTIVE_TIMEOUT);
    }

    case 'unblock-node': {
        admin_require_post($method);
        $pubkey = admin_str($input, 'pubkey');
        if ($pubkey === '') { fngate_fail(400, 'pubkey is required'); }
        fngate_call(GATE_DOMAIN, 'unblock-node', ['pubkey' => $pubkey],
            admin_auth(), ADMIN_TIMEOUT_SEC);
    }

    // ---- database (new surface) -----------------------------------------

    case 'db-status':
        fngate_call(GATE_DOMAIN, 'db-status', [], admin_auth(), ADMIN_TIMEOUT_SEC);

    case 'db-backup': {
        admin_require_post($method);
        $params = [];
        if (admin_present($input, 'note')) {
            $params['note'] = admin_str($input, 'note');
        }
        fngate_call(GATE_DOMAIN, 'db-backup', $params,
            admin_auth(), DESTRUCTIVE_TIMEOUT);
    }

    case 'db-clear-tunnels':
    case 'db-clear-nodes': {
        admin_require_post($method);
        fngate_call(GATE_DOMAIN, $action,
            ['confirm' => (string) ($input['confirm'] ?? '')],
            admin_auth(), DESTRUCTIVE_TIMEOUT);
    }

    case 'db-reset': {
        admin_require_post($method);
        $params = ['confirm' => (string) ($input['confirm'] ?? '')];
        if (admin_present($input, 'keep_admin_token')) {
            $params['keep_admin_token'] = admin_bool($input['keep_admin_token']);
        }
        fngate_call(GATE_DOMAIN, 'db-reset', $params,
            admin_auth(), DESTRUCTIVE_TIMEOUT);
    }

    // ---- gate health -----------------------------------------------------

    case 'gate-ping':
        fngate_call(GATE_DOMAIN, 'gate-ping', [],
            ['kind' => 'none', 'value' => ''], 30.0);

    case 'gate-result':
        // The other half of the timeout story: a caller that stopped waiting
        // can still collect the result, because the request id is the
        // capability and the response outlives the wait.
        fngate_result(GATE_DOMAIN, (string) ($_GET['id'] ?? ''));

    default:
        fngate_fail(400, 'Unknown action: ' . json_encode($action) . '. Available: '
            . 'login, logout, session, ponds, create-pond, patch-pond, '
            . 'pond-status, create-chorus, remove-chorus-member, nodes, '
            . 'force-deregister, blocklist, block-node, unblock-node, '
            . 'db-status, db-backup, db-clear-tunnels, db-clear-nodes, db-reset');
}
