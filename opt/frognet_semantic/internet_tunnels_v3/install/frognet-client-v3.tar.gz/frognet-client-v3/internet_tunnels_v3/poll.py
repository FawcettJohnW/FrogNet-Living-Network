"""
poll.py — The single poll-diff-act cycle.

Every POLL_INTERVAL seconds:
  1. GET /api/v1/my-channels?pubkey=<PUBKEY> from the broker
  2. Compare digest against last known
  3. If different: diff against local tunnels, create/destroy, fork runMerge
  4. If same: sleep

Uses a persistent HTTP connection (urllib keeps the socket alive with
Connection: keep-alive). When the semantic proxy is in front, unchanged
responses come back as ~21 byte SAME tokens.
"""

import json
import os

import subprocess
import ssl
import time
import urllib.request
from typing import Dict, List, Optional, Set

from . import config
from .wg import (find_next_wg_iface, teardown_wg_iface,
                 wg_handshake_age, frognet_echo)

# ---------------------------------------------------------------------------
# frognet0 — virtual interface for chorus IPs (10.254.x.x)
# ---------------------------------------------------------------------------

FROGNET_IFACE = "frognet0"


def _ensure_frognet0():
    """Create frognet0 dummy interface if it doesn't exist."""
    r = subprocess.run(["ip", "link", "show", FROGNET_IFACE],
                       capture_output=True, check=False)
    if r.returncode != 0:
        subprocess.run(["ip", "link", "add", FROGNET_IFACE, "type", "dummy"],
                       check=False)
        subprocess.run(["ip", "link", "set", FROGNET_IFACE, "up"], check=False)
        config.log.info("Created %s virtual interface", FROGNET_IFACE)


def _live_chorus_ips() -> Set[str]:
    """Return set of 10.254.x.x addresses currently on frognet0."""
    r = subprocess.run(
        ["ip", "-4", "addr", "show", FROGNET_IFACE],
        capture_output=True, text=True, check=False)
    ips = set()
    for line in r.stdout.splitlines():
        line = line.strip()
        if line.startswith("inet 10.254."):
            ip = line.split()[1].split("/")[0]
            ips.add(ip)
    return ips


def _add_chorus_ip(chorus_ip: str, subnet: str):
    prefix_len = subnet.split("/")[1]
    subprocess.run(
        ["ip", "addr", "add", f"{chorus_ip}/{prefix_len}",
         "dev", FROGNET_IFACE],
        capture_output=True, check=False)
    config.log.info("Added chorus IP %s/%s to %s",
                    chorus_ip, prefix_len, FROGNET_IFACE)


def _remove_chorus_ip(chorus_ip: str):
    subprocess.run(
        ["ip", "addr", "del", f"{chorus_ip}/24", "dev", FROGNET_IFACE],
        capture_output=True, check=False)
    config.log.info("Removed chorus IP %s from %s", chorus_ip, FROGNET_IFACE)


def _sync_chorus_ips(chorus_assignments: List[dict]):
    """
    Diff broker chorus_assignments against live frognet0 addresses.
    Add new, remove departed.
    """
    broker_ips: Dict[str, str] = {
        a["chorus_ip"]: a["subnet"] for a in chorus_assignments
    }
    live_ips = _live_chorus_ips()

    for ip in live_ips - set(broker_ips.keys()):
        _remove_chorus_ip(ip)

    for ip, subnet in broker_ips.items():
        if ip not in live_ips:
            _add_chorus_ip(ip, subnet)

# ---------------------------------------------------------------------------
# HTTP client — persistent connection to broker
# ---------------------------------------------------------------------------

_ssl_ctx = None
_opener = None


def _get_opener():
    """Lazy-init a urllib opener that reuses TCP connections."""
    global _ssl_ctx, _opener
    if _opener is None:
        _ssl_ctx = ssl.create_default_context()
        _ssl_ctx.check_hostname = False
        _ssl_ctx.verify_mode = ssl.CERT_NONE
        handler = urllib.request.HTTPSHandler(context=_ssl_ctx)
        _opener = urllib.request.build_opener(handler)
    return _opener


def broker_get(path: str, params: dict = None) -> dict:
    url = f"{config.BROKER_URL}{path}"
    if params:
        qs = "&".join(f"{k}={urllib.request.quote(str(v))}" for k, v in params.items())
        url += ("&" if "?" in url else "?") + qs
    req = urllib.request.Request(url, headers={"Connection": "keep-alive"})
    with _get_opener().open(req, timeout=30) as resp:
        return json.loads(resp.read().decode())


def broker_post(path: str, body: dict) -> dict:
    url = f"{config.BROKER_URL}{path}"
    data = json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, method="POST",
                                 headers={"Content-Type": "application/json",
                                          "Connection": "keep-alive"})
    with _get_opener().open(req, timeout=30) as resp:
        return json.loads(resp.read().decode())


# ---------------------------------------------------------------------------
# Local tunnel state
# ---------------------------------------------------------------------------

# channel_name -> {tunnel_name, iface, wg_config, subnet}
_active_tunnels: Dict[str, dict] = {}


def _load_local_state():
    """Load active tunnel state from disk on startup."""
    _active_tunnels.clear()
    for sf_path in config.ACTIVE_DIR.glob("*.json"):
        try:
            with open(sf_path) as f:
                sf = json.load(f)
            ch = sf.get("channel_name", "")
            if ch:
                _active_tunnels[ch] = sf
        except (json.JSONDecodeError, OSError):
            sf_path.unlink(missing_ok=True)
    config.log.info("Loaded %d active tunnel(s) from disk", len(_active_tunnels))


def _save_tunnel_state(channel_name: str, info: dict):
    path = config.ACTIVE_DIR / f"{info['tunnel_name']}.json"
    path.write_text(json.dumps(info, indent=4))


def _remove_tunnel_state(tunnel_name: str):
    (config.ACTIVE_DIR / f"{tunnel_name}.json").unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# Tunnel bring-up / teardown
# ---------------------------------------------------------------------------

def _bring_up_tunnel(channel: dict) -> bool:
    """Bring up a WireGuard tunnel for a channel. Returns True on success."""
    wg_config = channel["wg_config"]
    tunnel_name = channel["tunnel_name"]
    remote_subnets = wg_config.get("remote_subnets", [])
    channel_name = channel["channel_name"]

    config.log.info("BRING_UP: %s tunnel=%s subnets=%s",
                    channel_name, tunnel_name, remote_subnets)

    from . import wg as wg_mod

    with wg_mod._wg_up_lock:
        iface = find_next_wg_iface()
        conf_path = config.CONF_DIR / f"{iface}.conf"
        conf_path.write_text(
            f"# FrogNet Tunnel - {tunnel_name}\n"
            f"[Interface]\n"
            f"Address = {wg_config['edge_ip']}/{wg_config['edge_mask']}\n"
            f"PrivateKey = {config.PRIVKEY}\n"
            f"Table = off\n"
            f"\n"
            f"[Peer]\n"
            f"PublicKey = {wg_config['droplet_pubkey']}\n"
            f"Endpoint = {wg_config['droplet_endpoint']}\n"
            f"AllowedIPs = {wg_config['allowed_ips']}\n"
            f"PersistentKeepalive = 25\n"
        )
        conf_path.chmod(0o600)

        r = subprocess.run(["wg-quick", "up", iface],
                           capture_output=True, text=True, check=False)
        if r.returncode != 0:
            config.log.error("BRING_UP: wg-quick up %s FAILED: %s",
                             iface, r.stderr.strip())
            conf_path.unlink(missing_ok=True)
            return False

    # Wait for handshake
    for _ in range(20):
        age = wg_handshake_age(iface)
        if age is not None and age < 30:
            break
        time.sleep(0.25)
    else:
        config.log.warning("BRING_UP: %s no handshake after 5s — continuing anyway",
                           iface)

    # Install routes
    for sn in remote_subnets:
        gw = sn.replace(".0/24", ".1")
        r = subprocess.run(
            ["ip", "route", "replace", sn, "via", gw, "dev", iface,
             "metric", "100", "onlink"],
            capture_output=True, text=True, check=False)
        if r.returncode == 0:
            config.log.info("Route: %s via %s dev %s metric 100", sn, gw, iface)
        else:
            config.log.warning("BRING_UP: route %s failed: %s", sn, r.stderr.strip())

    # Save local state
    info = {
        "channel_name":     channel_name,
        "tunnel_name":      tunnel_name,
        "interface":        iface,
        "remote_subnets":   remote_subnets,
        "droplet_endpoint": wg_config.get("droplet_endpoint", ""),
        "local_gateway":    config.LOCAL_GW,
        "created":          time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    _active_tunnels[channel_name] = info
    _save_tunnel_state(channel_name, info)

    config.log.info("BRING_UP: %s UP on %s", tunnel_name, iface)
    return True


def _tear_down_tunnel(channel_name: str):
    """Tear down a tunnel by channel name."""
    info = _active_tunnels.pop(channel_name, None)
    if not info:
        return

    iface = info.get("interface", "")
    tunnel_name = info.get("tunnel_name", "")
    config.log.info("TEAR_DOWN: %s on %s", tunnel_name, iface)

    if iface:
        for sn in info.get("remote_subnets", []):
            gw = sn.replace(".0/24", ".1")
            subprocess.run(["ip", "route", "del", sn, "via", gw, "dev", iface],
                           capture_output=True, check=False)
        teardown_wg_iface(iface)

    _remove_tunnel_state(tunnel_name)

    # Notify broker
    try:
        broker_post("/api/v1/leave", {
            "pubkey": config.PUBKEY,
            "tunnel_name": tunnel_name,
        })
    except Exception as e:
        config.log.warning("TEAR_DOWN: broker leave failed: %s", e)

    config.log.info("TEAR_DOWN: %s DOWN", tunnel_name)


# ---------------------------------------------------------------------------
# The poll cycle
# ---------------------------------------------------------------------------

def poll_once() -> bool:
    """Execute one poll-diff-act cycle. Returns True if anything changed."""

    try:
        resp = broker_get("/api/v1/my-channels", {"pubkey": config.PUBKEY})
    except Exception as e:
        config.log.warning("POLL: broker unreachable: %s", e)
        return False

    digest   = resp.get("digest", "")
    channels = resp.get("channels", [])
    chorus_assignments = resp.get("chorus_assignments", [])

    config.log.info("POLL: broker returned %d channels, digest=%s (last=%s)",
                    len(channels), digest, config.last_digest)

    # Quick check: if digest matches, nothing changed
    if digest and digest == config.last_digest:
        config.log.info("POLL: digest unchanged — nothing to do")
        return False

    config.last_digest = digest

    # Build sets for diff
    broker_channels: Dict[str, dict] = {}
    for ch in channels:
        broker_channels[ch["channel_name"]] = ch

    local_channels: Set[str] = set(_active_tunnels.keys())
    broker_names: Set[str] = set(broker_channels.keys())

    to_create = broker_names - local_channels
    to_remove = local_channels - broker_names
    # Channels in both sets: check if config changed (endpoint, etc.)
    to_update = set()
    for ch_name in broker_names & local_channels:
        local_ep = _active_tunnels[ch_name].get("droplet_endpoint", "")
        broker_ep = broker_channels[ch_name]["wg_config"].get("droplet_endpoint", "")
        if local_ep != broker_ep:
            to_update.add(ch_name)

    if not to_create and not to_remove and not to_update:
        config.log.info("POLL: channel set matches local state — nothing to do")
        return False

    config.log.info("POLL: changes detected — create=%s remove=%s update=%s",
                    sorted(to_create), sorted(to_remove), sorted(to_update))

    changed = False

    # Remove tunnels that are no longer in the broker list
    for ch_name in to_remove:
        _tear_down_tunnel(ch_name)
        changed = True

    # Update tunnels with changed config (tear down + recreate)
    for ch_name in to_update:
        _tear_down_tunnel(ch_name)
        if _bring_up_tunnel(broker_channels[ch_name]):
            changed = True

    # Create new tunnels
    for ch_name in to_create:
        if _bring_up_tunnel(broker_channels[ch_name]):
            changed = True

    # Always sync chorus IPs — cheap operation, no digest needed
    _sync_chorus_ips(chorus_assignments)

    return changed


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

def run_poll_loop():
    """The entire daemon: one loop, one purpose."""

    _ensure_frognet0()
    _load_local_state()

    config.log.info("Starting poll loop (interval=%ds)", config.POLL_INTERVAL_SEC)

    while config.running:
        changed = False
        try:
            changed = poll_once()
        except Exception as e:
            config.log.exception("POLL: unhandled error: %s", e)

        if changed:
            config.log.info("POLL: changes applied — forking runMerge")
            try:
                subprocess.Popen(["/usr/local/bin/runMerge.bash"])
            except Exception as e:
                config.log.error("POLL: failed to fork runMerge: %s", e)

        # Sleep in 1-second increments so we respond to shutdown promptly
        for _ in range(config.POLL_INTERVAL_SEC):
            if not config.running:
                return
            time.sleep(1)


def shutdown_all():
    """Tear down all active tunnels on daemon exit."""
    for ch_name in list(_active_tunnels.keys()):
        _tear_down_tunnel(ch_name)
