"""
Global configuration for frognet-tunnel-daemon v3 (pond/chorus).

Reads /etc/frognet/tunnel.conf which now contains:
  BROKER_URL=https://streamingfrog.com:8443/frognet-broker
  PUBKEY=<wireguard public key>

Node identity (name, subnet) is discovered from the local system,
same as before. Pond/chorus membership is broker-side only — the
daemon doesn't know or care about them.
"""

import glob
import logging
import os
import signal
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------

VERSION = "3.0.0"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [v" + VERSION + "] %(name)s %(levelname)s %(message)s",
    stream=sys.stderr,
)
log = logging.getLogger("frognet.tunnel-daemon")


def dbg(msg):
    log.info("DBG %s", msg)


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

CONF_FILE  = Path("/etc/frognet/tunnel.conf")
CONF_DIR   = Path("/etc/wireguard")
STATE_DIR  = Path("/var/lib/frognet-tunnel")
ACTIVE_DIR = STATE_DIR / "active"
PID_FILE   = Path("/run/frognet/tunnel-daemon.pid")

# ---------------------------------------------------------------------------
# Tunable constants (env-overridable)
# ---------------------------------------------------------------------------

POLL_INTERVAL_SEC          = int(os.environ.get("FROGNET_TUNNEL_POLL_SEC",           "300"))
HANDSHAKE_DEAD_SEC         = int(os.environ.get("FROGNET_TUNNEL_HANDSHAKE_DEAD_SEC", "180"))
GATEWAY_GRACE_SEC          = int(os.environ.get("FROGNET_TUNNEL_GW_GRACE_SEC",       "120"))
GATEWAY_CHECK_INTERVAL_SEC = int(os.environ.get("FROGNET_TUNNEL_GW_CHECK_SEC",        "60"))
GATEWAY_FAIL_THRESHOLD     = int(os.environ.get("FROGNET_TUNNEL_GW_FAIL_THRESH",       "3"))
ECHO_TIMEOUT_SEC           = float(os.environ.get("FROGNET_ECHO_TIMEOUT_SEC",        "60.0"))
RECONNECT_BASE_SEC         = 5
RECONNECT_MAX_SEC          = 120

# ---------------------------------------------------------------------------
# Node identity — populated by load_config()
# ---------------------------------------------------------------------------

running       = True

BROKER_URL    = ""
HOSTNAME      = ""
NODE_NAME     = ""
LOCAL_SUBNET  = ""
LOCAL_GW      = ""
SUBNET_PREFIX = ""
SUBNET_OCTET  = 0
CHANNEL_NAME  = ""
PUBKEY        = ""
PRIVKEY       = ""

# Last known digest from the broker — used for quick change detection
last_digest   = ""

# ---------------------------------------------------------------------------
# Signal handling
# ---------------------------------------------------------------------------

def _shutdown(sig, frame):
    global running
    log.info("Shutting down (signal %d)", sig)
    running = False

signal.signal(signal.SIGTERM, _shutdown)
signal.signal(signal.SIGINT, _shutdown)


# ---------------------------------------------------------------------------
# load_config
# ---------------------------------------------------------------------------

def load_config():
    global BROKER_URL
    global HOSTNAME, NODE_NAME, LOCAL_SUBNET, LOCAL_GW, SUBNET_PREFIX
    global SUBNET_OCTET, CHANNEL_NAME, PUBKEY, PRIVKEY

    if not CONF_FILE.exists():
        log.error("Config file %s not found — run frognet_tunnel_setup.sh first", CONF_FILE)
        sys.exit(1)

    conf = {}
    with open(CONF_FILE) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                k, v = line.split("=", 1)
                conf[k.strip()] = v.strip()

    BROKER_URL = conf.get("BROKER_URL", "")
    if not BROKER_URL:
        log.info("No BROKER_URL in %s — online features disabled. Exiting.", CONF_FILE)
        sys.exit(0)

    HOSTNAME = subprocess.check_output(["hostname", "-s"], text=True).strip()

    # Discover node name from dnsmasq domain=
    NODE_NAME = ""
    for dnsmasq_conf in glob.glob("/etc/dnsmasq.d/*.conf"):
        try:
            with open(dnsmasq_conf) as f:
                for dline in f:
                    dline = dline.strip()
                    if dline.startswith("domain="):
                        NODE_NAME = dline.split("=", 1)[1].strip()
                        break
        except OSError:
            pass
        if NODE_NAME:
            break

    if not NODE_NAME:
        log.error("No domain= found in /etc/dnsmasq.d/*.conf")
        sys.exit(1)

    # Discover local subnet
    out = subprocess.check_output(["ip", "-4", "addr", "show"], text=True)
    for line in out.splitlines():
        line = line.strip()
        if ("inet 10." in line
                and "inet 10.253." not in line
                and "inet 10.254." not in line):
            parts = line.split()
            idx = next((i for i, p in enumerate(parts) if p == "inet"), -1)
            if idx >= 0 and idx + 1 < len(parts):
                addr_cidr = parts[idx + 1]
                ip = addr_cidr.split("/")[0]
                LOCAL_SUBNET  = ip.rsplit(".", 1)[0] + ".0/24"
                LOCAL_GW      = ip.rsplit(".", 1)[0] + ".1"
                SUBNET_PREFIX = ip.rsplit(".", 1)[0]
                SUBNET_OCTET  = int(ip.split(".")[2])
                break

    if not LOCAL_SUBNET:
        log.error("No 10.x.x.x address found (excluding 10.253.x.x transit and 10.254.x.x chorus ranges)")
        sys.exit(1)

    CHANNEL_NAME = f"{NODE_NAME}-{SUBNET_PREFIX}"

    # WireGuard keys
    privkey_file = STATE_DIR / "node_private.key"
    pubkey_file  = STATE_DIR / "node_public.key"
    if not privkey_file.exists() or not pubkey_file.exists():
        log.error("WireGuard keypair missing — run frognet_tunnel_setup.sh first")
        sys.exit(1)

    PRIVKEY = privkey_file.read_text().strip()
    PUBKEY  = pubkey_file.read_text().strip()

    log.info("Config: broker=%s", BROKER_URL)
    log.info("Identity: node=%s host=%s subnet=%s channel=%s octet=%d",
             NODE_NAME, HOSTNAME, LOCAL_SUBNET, CHANNEL_NAME, SUBNET_OCTET)
