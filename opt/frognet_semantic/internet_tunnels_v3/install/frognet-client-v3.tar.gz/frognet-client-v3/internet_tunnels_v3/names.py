"""
Channel name parsing, deterministic tunnel naming, joiner/host directionality,
and kernel route queries.
"""

import subprocess
from typing import Set, Tuple

from . import config


def parse_channel_name(ch_name: str) -> Tuple[str, int]:
    """Parse 'BlackBox-10.101.10' -> ('BlackBox', 10).  Returns ('', 0) on error."""
    idx = ch_name.rfind("-10.101.")
    if idx < 0:
        return ("", 0)
    node_name = ch_name[:idx]
    parts = ch_name[idx + 1:].split(".")
    if len(parts) != 3:
        return ("", 0)
    try:
        return (node_name, int(parts[2]))
    except ValueError:
        return ("", 0)


def deterministic_tunnel_name(our_name: str, our_octet: int,
                               remote_name: str, remote_octet: int) -> str:
    if our_octet < remote_octet:
        return f"{our_name}-to-{remote_name}"
    return f"{remote_name}-to-{our_name}"


def we_are_joiner(remote_octet: int) -> bool:
    s = config.SUBNET_OCTET + remote_octet
    return config.SUBNET_OCTET > remote_octet


def non_tunnel_routed_subnets() -> Set[str]:
    """Return 10.101.x.0/24 subnets reachable via non-WG, low-metric routes."""
    subnets = set()
    try:
        out = subprocess.check_output(["ip", "route", "show"], text=True)
        for line in out.splitlines():
            parts = line.split()
            if not parts:
                continue
            cidr = parts[0]
            if not (cidr.startswith("10.101.") and cidr.endswith("/24")):
                continue
            if "dev" in parts:
                di = parts.index("dev")
                if di + 1 < len(parts) and parts[di + 1].startswith("wg"):
                    continue
            if "metric" in parts:
                mi = parts.index("metric")
                if mi + 1 < len(parts):
                    try:
                        if int(parts[mi + 1]) >= 100:
                            continue
                    except ValueError:
                        pass
            subnets.add(cidr)
    except Exception as e:
        config.log.error("non_tunnel_routed_subnets: %s", e)
    return subnets
