"""
WireGuard interface helpers and frognet echo probe.
"""

import re
import subprocess
import time
import urllib.request
import threading
_wg_up_lock = threading.RLock()

from typing import Optional

from . import config


def find_next_wg_iface() -> str:
    for n in range(32):
        r = subprocess.run(["ip", "link", "show", f"wg{n}"],
                           capture_output=True, check=False)
        if r.returncode != 0:
            return f"wg{n}"
    raise RuntimeError("Too many WireGuard interfaces (32+)")


def teardown_wg_iface(iface: str):
    config.dbg(f"_teardown_wg_iface: {iface}")
    conf_path = config.CONF_DIR / f"{iface}.conf"
    try:
        subprocess.run(["ip", "link", "show", iface],
                       capture_output=True, check=True)
    except subprocess.CalledProcessError:
        config.log.info("_teardown_wg_iface: %s not in kernel", iface)
        conf_path.unlink(missing_ok=True)
        return

    if conf_path.exists():
        r = subprocess.run(["wg-quick", "down", iface],
                           capture_output=True, text=True, check=False)
        if r.returncode != 0:
            config.log.warning("_teardown_wg_iface: wg-quick down %s failed: %s",
                        iface, r.stderr.strip())
    else:
        subprocess.run(["ip", "link", "set", iface, "down"],
                       capture_output=True, check=False)
        subprocess.run(["ip", "link", "delete", iface],
                       capture_output=True, check=False)
    config.log.info("Torn down %s", iface)


def wg_handshake_age(iface: str) -> Optional[float]:
    try:
        wg = subprocess.run(["wg", "show", iface],
                            capture_output=True, text=True, check=False)
        for ln in (wg.stdout or "").splitlines():
            ln = ln.strip()
            if not ln.startswith("latest handshake:"):
                continue
            age_str = ln.split(":", 1)[1].strip()
            total_sec = 0
            for val, unit in re.findall(r'(\d+)\s+(second|minute|hour|day)', age_str):
                val = int(val)
                if "second" in unit:   total_sec += val
                elif "minute" in unit: total_sec += val * 60
                elif "hour" in unit:   total_sec += val * 3600
                elif "day" in unit:    total_sec += val * 86400
            return float(total_sec)
    except Exception as e:
        config.log.warning("_wg_handshake_age: %s: %s", iface, e)
    return None


def frognet_echo(ip: str, timeout: float = None) -> Optional[float]:
    """HTTP echo through local proxy semantic layer to remote node.
    Returns RTT in seconds, or None on failure."""
    if timeout is None:
        timeout = config.ECHO_TIMEOUT_SEC
    url = f"http://{ip}:8080/frognet_echo.php"
    try:
        t0 = time.monotonic()
        with urllib.request.urlopen(
                urllib.request.Request(url), timeout=timeout) as resp:
            body = resp.read()
        if not body:
            config.log.warning("_frognet_echo: %s returned empty body", ip)
            return None
        return time.monotonic() - t0
    except Exception as e:
        config.log.warning("_frognet_echo: %s %s: %s", ip, type(e).__name__, e)
        return None


def startup_reconcile():
    """At startup: tear down any WG interfaces with dead/no handshake,
    remove state files whose interface is no longer live."""
    import glob
    import json
    import os

    config.log.info("Startup reconciliation...")
    try:
        result = subprocess.run(["wg", "show", "interfaces"],
                                capture_output=True, text=True, check=False)
        live_ifaces = set(result.stdout.strip().split()) if result.stdout.strip() else set()
    except Exception as e:
        config.log.error("startup_reconcile: wg show interfaces failed: %s", e)
        live_ifaces = set()

    config.log.info("startup_reconcile: live wg ifaces=%s", sorted(live_ifaces))

    dead = set()
    for iface in sorted(live_ifaces):
        age = wg_handshake_age(iface)
        if age is None or age >= config.HANDSHAKE_DEAD_SEC:
            config.log.warning("startup_reconcile: %s dead (handshake=%s) — tearing down",
                        iface, f"{age}s" if age is not None else "never")
            dead.add(iface)
        else:
            config.log.info("startup_reconcile: %s alive (handshake=%ds)", iface, age)

    for iface in dead:
        teardown_wg_iface(iface)

    live_ifaces -= dead

    for sf_path in glob.glob(str(config.ACTIVE_DIR / "*.json")):
        try:
            with open(sf_path) as f:
                sf = json.load(f)
            if sf.get("interface", "") not in live_ifaces:
                os.unlink(sf_path)
        except (json.JSONDecodeError, OSError):
            try:
                os.unlink(sf_path)
            except OSError:
                pass

    config.log.info("startup_reconcile: done — live=%s dead=%s",
             sorted(live_ifaces), sorted(dead))
