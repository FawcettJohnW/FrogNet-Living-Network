# fish completion for frog
complete -c frog -n "__fish_use_subcommand" -a "user team team-member message known-frognet sensor iahost actuator well-known-site sensor-data" -d "Entity"
complete -c frog -n "__fish_seen_subcommand_from user team team-member message known-frognet sensor iahost actuator well-known-site sensor-data" -a "create get list update delete list-all" -d "Action"
complete -c frog -n "__fish_seen_subcommand_from message messages" -a "inbox outbox" -d "Mailbox views"
