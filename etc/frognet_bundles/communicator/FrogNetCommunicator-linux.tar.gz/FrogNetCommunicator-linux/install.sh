#!/usr/bin/env bash
set -e
PREFIX="${PREFIX:-/opt/frognet-communicator}"
BIN="${BIN:-/usr/local/bin}"
echo "Installing FrogNet Communicator -> $PREFIX"
sudo mkdir -p "$PREFIX"
sudo cp -r bundle "$PREFIX/"
sudo cp frognet-communicator "$PREFIX/"
sudo ln -sf "$PREFIX/frognet-communicator" "$BIN/frognet-communicator"
mkdir -p "$HOME/.local/share/applications"
cp frognet-communicator.desktop "$HOME/.local/share/applications/"
echo "Done. Launch:  frognet-communicator --host <HOST> --name '<You>'"
echo "Requires: python3 (tkinter) and ffmpeg for A/V."
