FrogNet Communicator — Linux
============================
Self-contained: all bundle code is under ./bundle (no /etc/frognet_bundles needed).

Run without installing:   ./frognet-communicator --host <HOST> --name "<You>"
Install system-wide:      ./install.sh         (-> /opt/frognet-communicator, launcher in /usr/local/bin)

Requirements: python3 with tkinter; ffmpeg (for A/V calls).
A/V calls ride the canonical SotF media stack (adaptive, one-up/one-down per client).
Multi-person calls: in the Call tab, "add to group" on each person, then "Start Group Call".
Stats overlay: press 'o' (or the ⓘ button) during a call.
