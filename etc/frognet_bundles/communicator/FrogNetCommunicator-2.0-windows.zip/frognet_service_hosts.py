#!/usr/bin/env python3
"""
frognet_service_hosts — generic merge-end service-host election.

At the end of a converged runMerge pass, derive the LIVE service set from the
transient (consolidating the individual <Role>Candidate tuples + the System sensor),
elect each role through its registry handler, and emit `<role>.frognet <winner>`
lines for the committed /etc/hosts block. ONE generic loop — no per-role hook.

Dynamic, real-time, derived: the service list is not maintained anywhere. A role is
live when it has BOTH a candidate tuple present in the transient AND a registered
handler in format_registry (candidate without a handler can't be scored; handler
without candidates has nobody to elect). Drop in the first AIHost candidate and
aihost.frognet appears; pull the last and it falls out.

Memory, not messages: reads tuples, never probes. Any error degrades to "emit no
role lines this pass" so a merge can never break on this.
"""
from __future__ import annotations
from typing import Dict, List, Optional

import frognet_tuples as T


def _role_handlers(log=lambda s: None) -> Dict[str, object]:
    """role_name -> handler. Prefer the one registry in core; if importing it fails,
    log the REAL exception (don't guess) and rebuild ROLE_HANDLERS by importing the
    role-handler modules DIRECTLY. format_registry also imports the lxml-backed FORMAT
    handlers at module top and (on an older box) may predate ROLE_HANDLERS entirely —
    either would otherwise strand the role handlers, which carry no such dependency."""
    for modpath in ("core.role_registry", "role_registry",
                    "core.format_registry", "format_registry"):
        try:
            mod = __import__(modpath, fromlist=["ROLE_HANDLERS"])
            return dict(mod.ROLE_HANDLERS)
        except Exception as e:
            log(f"SERVICE_ELECT role_registry_import_failed path={modpath} err={e!r}")
    out: Dict[str, object] = {}
    for role, modname, clsname in (
            ("mediahost",    "sotf_handler",     "SotFMediaHandler"),
            ("databasehost", "database_handler", "DatabaseRoleHandler")):
        err = None
        for pkg in ("core.", ""):
            try:
                m = __import__(pkg + modname, fromlist=[clsname])
                out[role] = getattr(m, clsname)()
                break
            except Exception as e:
                err = e
        else:
            log(f"SERVICE_ELECT role={role} direct_load_failed err={err!r}")
    return out


def _live_roles(handlers: Dict[str, object], dbhost: str) -> List[str]:
    """Consolidate the individual service tuples into the live service set: a role is
    live iff its handler's CANDIDATE_TYPE has at least one tuple present, OR a .1 host
    advertises the role's capability via the System sensor. Derived from what's
    actually registered — nothing to maintain."""
    live = []
    for name, h in handlers.items():
        ctype = getattr(h, "CANDIDATE_TYPE", None)
        present = False
        if ctype:
            try:
                present = bool(T.get(ctype, "Candidate", dbhost=dbhost))
            except Exception:
                present = False
        # even with no specialist candidate, the .1 hosts are implicit candidates
        # (System sensor); keep the role live so a .1 can still win it.
        live.append(name)
    return live


def service_host_lines(dbhost: str = "databasehost_control.frognet", logger=None) -> List[str]:
    """Elect every live service role and return the `<role>.frognet <ip>` lines to
    append to the committed /etc/hosts block. Each role is elected through its
    registry handler over capability memory (the LAN/WAN split is read by the
    election from the reach_plane tuple, not passed in). Returns [] on any failure.

    `logger(str)` (optional) receives one-shot election diagnostics so a merge log
    (or the `python3 frognet_service_hosts.py` dry-run) shows exactly what each role
    saw — every candidate's bucket(lan/wan) + ffmpeg/libvpx + score, and the winner
    or why there wasn't one. Pure read; no behaviour change when logger is None.
    """
    log = logger or (lambda s: None)
    try:
        from frognet_role_elect import gather_candidates
    except Exception as e:
        log(f"SERVICE_ELECT skipped reason=role_elect_import_failed err={e}")
        return []
    handlers = _role_handlers(log)
    if not handlers:
        log("SERVICE_ELECT skipped reason=no_role_handlers "
            "(registry AND direct role-handler load both failed — see errs above)")
        return []
    lines = []
    for role in _live_roles(handlers, dbhost):
        h = handlers[role]
        try:
            hosts_list, lan_list = gather_candidates(h, dbhost=dbhost)
        except Exception as e:
            log(f"SERVICE_ELECT role={role} reason=gather_failed err={e}")
            continue
        lan_ips = {c.get("lan_ip") for c in lan_list}
        for c in hosts_list:
            ip = c.get("lan_ip", "?")
            sc = ""
            if hasattr(h, "score"):
                try:
                    sc = h.score(c)
                except Exception as e:
                    sc = f"err({e})"
            log(f"SERVICE_CAND role={role} ip={ip} "
                f"bucket={'lan' if ip in lan_ips else 'wan'} "
                f"ffmpeg={c.get('ffmpeg')} libvpx={c.get('libvpx')} score={sc}")
        try:
            winner = h.evaluate(hosts_list, lan_list)
        except Exception as e:
            log(f"SERVICE_ELECT role={role} reason=evaluate_failed err={e}")
            winner = None
        wip = winner.get("lan_ip") if winner else None
        log(f"SERVICE_ELECT role={role} hosts={len(hosts_list)} "
            f"lan={len(lan_list)} winner={wip or 'none'}")
        if wip:
            lines.append(f"{wip} {role}.frognet")
    return lines


def apply_to_etc_hosts(etc_hosts: List[str],
                       dbhost: str = "databasehost_control.frognet",
                       logger=None) -> List[str]:
    """Given the assembled etc_hosts block, drop any existing <role>.frognet lines
    and append freshly-elected ones — for EVERY live service role uniformly,
    databasehost included. The LAN/WAN split is read by the election from the
    reach_plane tuple the merge wrote (the walk's loopback verdict), not probed here.
    Idempotent; safe every converged merge (the committer's change-detection collapses
    the no-op). The highest-IP databasehost line written earlier by
    select_database_host remains the FLOOR: if the transient is unreachable this
    returns etc_hosts unchanged and that floor stands."""
    role_lines = service_host_lines(dbhost=dbhost, logger=logger)
    if not role_lines:
        return etc_hosts
    role_names = {ln.split()[1] for ln in role_lines}
    out = [l for l in etc_hosts
           if not (len(l.split()) >= 2 and l.split()[1] in role_names)]
    out.extend(role_lines)
    return out


if __name__ == "__main__":
    import sys
    db = sys.argv[1] if len(sys.argv) > 1 else "databasehost_control.frognet"
    _log = lambda s: print(s, file=sys.stderr)   # diagnostics -> stderr, lines -> stdout
    for ln in service_host_lines(db, logger=_log):
        print(ln)
