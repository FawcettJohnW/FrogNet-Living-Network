#!/usr/bin/env python3
"""
sotf_ladder.py — the SotF-ACP degradation ladder, as policy (client-side, no core).

Canonical ladder (protocol constant). L7 is the richest rung, L0 the floor; the
controller degrades DOWN as the NETWORK's total throughput falls. Ordering is by
TOTAL wire cost of the rung (not any single track), so every step down sheds load:

  L7 CHORUS    stereo audio + 720p video
  L6 ENSEMBLE  stereo audio + 480p video
  L5 DUET      stereo audio + 360p grayscale video
  L4 SOLO      stereo audio (audio only — video shed)
  L3 VOICE     mono audio
  L2 WHISPER   plaintext text on the wire
  L1 BEACON    token vocabulary (contested-link floor)
  L0 PULSE     implicit presence

Invariant: total cost is monotonically non-increasing from L7 to L0. When the
network degrades, drop to the next-lower rung to reduce load; the controller
always sends the HIGHEST rung the current total throughput can sustain — "the
highest level we are capable of" under the load ceiling.

Two things choose the rung:

  CEILING — the highest rung this machine may source, from capability + flags.
    Every video rung (L5-L7) requires BOTH a camera and the audio bed (mic);
    audio rungs (L3-L4) require a mic. So:
      camera + mic            -> L7 CHORUS
      --no-video / no camera  -> L4 SOLO    (top audio-only rung)
      --no-audio / no mic     -> L2 WHISPER (no audio bed => no video either)
      both off                -> L2 WHISPER
    Text/beacon/pulse (L0-L2) need no media hardware.

  BEARER — total network load pushes the rung DOWN (toward L0). The sender never
  rises above its ceiling and never above what the bearer sustains.

  send_level = highest ALLOWED rung that is no higher than the ceiling and no
  higher than the bearer permits. Walks DOWN to the next allowed rung; L0/L1 are
  always allowed, so a call never dies — the medium changes instead.
"""
from __future__ import annotations

from typing import Set

# kinds, by what the rung carries
VIDEO_AUDIO, AUDIO, TEXT, PRESENCE = "video+audio", "audio", "text", "presence"

# idx, code, name, kind, and what the sender must have to SOURCE it.
# Higher idx = richer. needs_camera/needs_mic gate whether this machine can source it.
LEVELS = [
    {"idx": 0, "code": "L0", "name": "PULSE",    "kind": PRESENCE,    "needs_camera": False, "needs_mic": False},
    {"idx": 1, "code": "L1", "name": "BEACON",   "kind": TEXT,        "needs_camera": False, "needs_mic": False},
    {"idx": 2, "code": "L2", "name": "WHISPER",  "kind": TEXT,        "needs_camera": False, "needs_mic": False},
    {"idx": 3, "code": "L3", "name": "VOICE",    "kind": AUDIO,       "needs_camera": False, "needs_mic": True},
    {"idx": 4, "code": "L4", "name": "SOLO",     "kind": AUDIO,       "needs_camera": False, "needs_mic": True},
    {"idx": 5, "code": "L5", "name": "DUET",     "kind": VIDEO_AUDIO, "needs_camera": True,  "needs_mic": True},
    {"idx": 6, "code": "L6", "name": "ENSEMBLE", "kind": VIDEO_AUDIO, "needs_camera": True,  "needs_mic": True},
    {"idx": 7, "code": "L7", "name": "CHORUS",   "kind": VIDEO_AUDIO, "needs_camera": True,  "needs_mic": True},
]
BY_IDX = {lv["idx"]: lv for lv in LEVELS}
MIN_IDX, MAX_IDX = 0, 7        # higher = richer
ALWAYS = {0, 1}                # PULSE/BEACON floor — never removed


def code(idx: int) -> str:
    return BY_IDX[idx]["code"]


def name(idx: int) -> str:
    return BY_IDX[idx]["name"]


def kind_of(idx: int) -> str:
    return BY_IDX[idx]["kind"]


def allowed_levels(have_camera: bool, have_mic: bool,
                   no_video: bool = False, no_audio: bool = False) -> Set[int]:
    """Rungs this sender may source. A video rung (L5-L7) needs a camera AND the
    audio bed; an audio rung (L3-L4) needs a mic. --no-video forbids video rungs;
    --no-audio forbids any rung that carries audio (which also forbids video, since
    every video rung rides the audio bed). PULSE/BEACON are always available."""
    cam_ok = have_camera and not no_video
    mic_ok = have_mic and not no_audio
    allowed: Set[int] = set(ALWAYS)
    for lv in LEVELS:
        if lv["needs_camera"] and not cam_ok:
            continue
        if lv["needs_mic"] and not mic_ok:
            continue
        allowed.add(lv["idx"])
    return allowed


def ceiling(have_camera: bool, have_mic: bool,
            no_video: bool = False, no_audio: bool = False) -> int:
    """Highest rung the sender may source = 'switch to the highest supported level'.
    Just the max allowed idx."""
    return max(allowed_levels(have_camera, have_mic, no_video, no_audio))


def send_level(ceiling_idx: int, bearer_idx: int, allowed: Set[int]) -> int:
    """The rung to send now: no higher than the ceiling, no higher than the bearer
    sustains, and must be allowed. Walk DOWN to the next allowed rung; L0 always
    satisfies."""
    want = min(ceiling_idx, bearer_idx)            # highest we're permitted
    for idx in range(want, MIN_IDX - 1, -1):       # walk down to next allowed
        if idx in allowed:
            return idx
    return MIN_IDX


def describe_ceiling(have_camera: bool, have_mic: bool,
                     no_video: bool = False, no_audio: bool = False) -> str:
    c = ceiling(have_camera, have_mic, no_video, no_audio)
    return f"{BY_IDX[c]['code']} {BY_IDX[c]['name']} ({kind_of(c)})"


if __name__ == "__main__":
    cases = [
        ("camera+mic, no flags",   True,  True,  False, False),
        ("--no-video",             True,  True,  True,  False),
        ("--no-audio",             True,  True,  False, True),
        ("--no-video --no-audio",  True,  True,  True,  True),
        ("no camera (mic only)",   False, True,  False, False),
        ("no camera, no mic",      False, False, False, False),
    ]
    print("CEILING (highest level the sender switches to):")
    for label, cam, mic, nv, na in cases:
        print(f"  {label:24} -> {describe_ceiling(cam, mic, nv, na)}")
    print("\nDEGRADE DOWN as total network load rises (full-capability sender):")
    allowed = allowed_levels(True, True)
    ce = ceiling(True, True)
    for bearer in range(MAX_IDX, MIN_IDX - 1, -1):
        lv = send_level(ce, bearer, allowed)
        print(f"  bearer sustains L{bearer} -> send {code(lv)} {name(lv)}")
