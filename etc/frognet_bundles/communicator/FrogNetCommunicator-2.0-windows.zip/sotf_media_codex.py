#!/usr/bin/env python3
"""
sotf_media_codex.py — the SotF media codex, as a WorkingMemory subclass.

UnREST as a class. Two planes, separated by what actually benefits from convergence
(getting this backwards wastes CPU diffing frames that never repeat):

  DATA (hot): audio + video frames. RAW and FAST out the video vector (send_frame),
    fire-and-forget. They do NOT go through the convergence codec. Live AV is never
    byte-identical tick to tick (sensor noise, re-encode), so SAME/DIFF would always
    say "changed" — you'd pay the full compare and gain nothing. The frame IS the
    payload; ship it. ffmpeg does capture/transcode/play OUTSIDE this class.

  CONTROL (cold): the LiveStream JSON bag, conn-info, bearer, status. Mostly-stable
    structured data, stored-at-calculation and read-at-use as a VARIABLE in the shared
    transient. THIS is where SAME/DIFF earns its keep: re-storing an unchanged bag is
    SAME (~0 bytes), a changed field is a small DIFF. Read at use, store at calculation,
    freely — convergence makes both weightless when nothing moved.

Control is MEMORY in the shared space, not messages to a peer. Many instances of a type
coexist — one LiveStream per stream/client, keyed (name,type,location). A reader sees the
whole via get_all-by-type and finds its part. hostReset() fires when databasehost.frognet
floated: drop owned keys, consistency-check perm, re-assert, refull. No timer, no poll.
"""
from __future__ import annotations

import json
import struct
from typing import Any, Callable, Dict, List, Optional, Tuple

from substrate import Codex, Freshness
from working_memory import WorkingMemory, TransientStore, PermStore

import sotf_metrics


LIVESTREAM_TYPE = "LiveStream"

# Control structure that lives in the shared space and DOES converge. Pure JSON.
CONTROL_FIELDS = ["conn_info", "ffmpeg_options", "status"]
CONTROL_FRESHNESS = {
    "conn_info":      Freshness.RESIDENT_ONCE,  # set once -> SAME forever after
    "ffmpeg_options": Freshness.LATEST_ONLY,    # the encoder options the producer runs
    "status":         Freshness.LATEST_ONLY,
}

# A producer's "conditions changed" flag: one tiny tuple, read JIT every loop. Boolean.
# The producer reads the options bag ONLY when tripped, then clears. No options diffing —
# the flag is cheaper than a get-and-compare.
#
# SINGLE-WRITER PER TUPLE IS THE CALLER'S CONTRACT. The codex does NOT enforce, detect,
# prevent, or arbitrate it, and must not. If two things write the same tuple the system
# will thrash and crash — and that is the WANTED behavior: the crash is how a programmer
# error surfaces. Defensive guards would hide the bug instead of exposing it. So this code
# just writes what it is told; honoring one-writer-per-tuple is the caller's job, and
# misuse is meant to blow up loudly, not be papered over.
def _flag_key(session: str, who: str) -> str:
    return f"FfmpegFlag.{session}.{who}"

_FRAME_HDR = struct.Struct("!IBII")   # seq, is_key, audio_len, video_len


def _ls_key(session: str, who: str) -> str:
    return f"{LIVESTREAM_TYPE}.{session}.{who}"

def pack_frame(seq: int, is_key: bool, audio: bytes, video: bytes) -> bytes:
    return _FRAME_HDR.pack(seq, 1 if is_key else 0, len(audio), len(video)) + audio + video

def unpack_frame(buf: bytes) -> Tuple[int, bool, bytes, bytes]:
    seq, key, al, vl = _FRAME_HDR.unpack_from(buf, 0)
    off = _FRAME_HDR.size
    return seq, bool(key), buf[off:off + al], buf[off + al:off + al + vl]


class SotFMediaCodex(WorkingMemory):
    """One participant's media codex: owns its LiveStream control instance (convergent
    JSON) in the transient, ships AV frames raw out the video vector."""

    def __init__(self, transient: TransientStore, perm: PermStore,
                 session: str, who: str,
                 send_frame: Callable[[bytes], None],
                 role: str = sotf_metrics.ROLE_SENDER):
        super().__init__(transient, perm)
        self.session = session
        self.who = who
        self.send_frame = send_frame
        self._ctl = Codex(None, "POST", f"sotf/ctl/{session}",
                          CONTROL_FIELDS, CONTROL_FRESHNESS, mode="json")
        self._ctl_ref: Optional[Dict[str, Any]] = None
        self.metrics = sotf_metrics.StreamMetrics(session, who, role)

    def _owned_keys(self):
        return [_ls_key(self.session, self.who)]

    def _consistency_check(self) -> None:
        key = _ls_key(self.session, self.who)
        st = self.p.load(key)
        if st is not None:
            st["type"] = LIVESTREAM_TYPE; st["session"] = self.session; st["who"] = self.who
            self.p.save(key, st)

    # ===== DATA PLANE — raw frames, video vector, fire-and-forget. No codec. =====
    def send_av(self, seq: int, is_key: bool, audio: bytes, video: bytes) -> None:
        """Ship one AV unit RAW out the video vector. No convergence — live AV never
        repeats, so diffing it is pure cost. ffmpeg produced these bytes; we move them."""
        self.send_frame(pack_frame(seq, is_key, audio, video))
        self.metrics.on_sent()

    def recv_av(self, buf: bytes) -> Tuple[int, bool, bytes, bytes]:
        seq, key, audio, video = unpack_frame(buf)
        self.metrics.on_received()
        return seq, key, audio, video

    # ===== CONTROL PLANE — JIT store/read of the LiveStream bag. SAME/DIFF here. =====
    def store_control(self, **bag: Any) -> str:
        """At the point you CALCULATE a control value, store it. Returns the convergence
        kind (full/diff/same); an unchanged store is SAME and counts ~0 wire bytes."""
        key = _ls_key(self.session, self.who)
        st = self._live(key) or {"type": LIVESTREAM_TYPE,
                                 "session": self.session, "who": self.who}
        st.update(bag)
        ctl_vals = {f: st.get(f) for f in CONTROL_FIELDS}
        frame, new_ref, kind = self._ctl.encode(ctl_vals, self._ctl_ref)
        self._ctl_ref = new_ref
        raw = len(json.dumps(ctl_vals, separators=(",", ":")).encode())
        self.metrics.on_ctl(kind=kind, wire=len(frame), raw=raw)
        self._commit(key, st)
        return kind

    def read_control(self, who: str) -> Optional[Dict[str, Any]]:
        return self._live(_ls_key(self.session, who))

    def read_livestreams(self) -> List[Dict[str, Any]]:
        getter = getattr(self.t, "all_by_type", None)
        if getter is None:
            return []
        return [v for v in getter(LIVESTREAM_TYPE) if isinstance(v, dict)]

    # ---- ffmpeg options as shared memory: the producer reads what to run ----
    def set_ffmpeg_options(self, options: Dict[str, Any], for_who: Optional[str] = None) -> str:
        """Write the ffmpeg options a producer should run, into ITS LiveStream control,
        and trip its flag. Scale-to-fit, EITHER DIRECTION: lower bitrate when a link is
        drowning, higher when it recovers — same path, the producer just runs whatever
        is in the bag. Called by whoever decides policy (a consumer, the server, the
        producer itself); for_who defaults to me, a consumer passes the producer's id.
        The producer doesn't know or care who called this. (One-writer-per-tuple is the
        caller's contract; this code does not guard it — misuse is meant to crash.)"""
        target = for_who or self.who
        key = _ls_key(self.session, target)
        st = self._live(key) or {"type": LIVESTREAM_TYPE,
                                 "session": self.session, "who": target}
        st["ffmpeg_options"] = options
        ctl_vals = {fld: st.get(fld) for fld in CONTROL_FIELDS}
        frame, new_ref, kind = self._ctl.encode(ctl_vals, self._ctl_ref)
        self._ctl_ref = new_ref
        raw = len(json.dumps(ctl_vals, separators=(",", ":")).encode())
        self.metrics.on_ctl(kind=kind, wire=len(frame), raw=raw)
        self._commit(key, st)
        self.t.upsert(_flag_key(self.session, target), {"type": "FfmpegFlag",
                      "session": self.session, "who": target, "changed": True})
        return kind

    def conditions_changed(self) -> bool:
        """JIT, every loop: cheap boolean read. SAME (weightless) until someone trips it.
        This is the producer's only steady-state control cost."""
        fl = self.t.get(_flag_key(self.session, self.who))
        return bool(fl and fl.get("changed"))

    def take_ffmpeg_options(self) -> Optional[Dict[str, Any]]:
        """Producer: flag was tripped -> read the options bag (pay the cost ONCE),
        clear the flag, return what ffmpeg should now run. Write-agnostic: never reads
        who set it."""
        st = self._live(_ls_key(self.session, self.who)) or {}
        self.t.upsert(_flag_key(self.session, self.who), {"type": "FfmpegFlag",
                      "session": self.session, "who": self.who, "changed": False})
        return st.get("ffmpeg_options")

    def hostReset(self) -> Dict[str, Any]:
        rep = super().hostReset()
        self._ctl_ref = None
        rep["control_refulled"] = True
        return rep
