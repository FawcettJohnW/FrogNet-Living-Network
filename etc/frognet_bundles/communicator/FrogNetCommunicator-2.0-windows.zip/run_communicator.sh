#!/usr/bin/env bash
HERE="$(cd "$(dirname "$0")" && pwd)"
export FROGNET_BUNDLES_ROOT="$HERE/bundles"
export FROGNET_COMMUNICATOR_HOME="$HERE"
exec python3 "$HERE/communicator.py" "$@"
