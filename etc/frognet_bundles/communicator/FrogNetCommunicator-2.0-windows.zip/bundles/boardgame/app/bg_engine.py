#!/usr/bin/env python3
"""bg_engine.py — resident UnRESTful backgammon engine. Comes up on the gameserver,
governs the shared tuple space, gets ready for customers. It does NOT serve requests;
it reads the space, runs the governor (authority: dice, turn gate, seating), writes the
Game object back — current state only. Players join by writing their own User objects.

  run:  bg_engine.py --gid <table> [--dbhost <ip> | --http <base>] [--hz 5]
"""
import argparse, time, random
import bg_governor as G
from bg_space import TupleSpace, HttpSpace

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gid", required=True)
    ap.add_argument("--name", default="gameserver", help="service name = SensorType region")
    ap.add_argument("--dbhost"); ap.add_argument("--http")
    ap.add_argument("--hz", type=float, default=5.0)
    ap.add_argument("--once", action="store_true")
    a = ap.parse_args()
    space = HttpSpace(a.gid, a.http, typ=a.name) if a.http else TupleSpace(a.gid, a.dbhost, typ=a.name)
    rng = random.SystemRandom()
    print(f"[engine] backgammon governor up: gid={a.gid} table region <{a.name}>/backgammon.{a.gid}/*")
    period = 1.0 / max(0.5, a.hz)
    while True:
        try:
            g = G.governor_step(space, a.gid, rng)
        except Exception as e:
            print("[engine] step error:", e)
        if a.once: break
        time.sleep(period)

if __name__ == "__main__":
    main()
