#!/usr/bin/env python3
"""Communicator launch shim — hands the generic game client its game id."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "..", "games-common"))
from game_client import main
main(default_game="hearts")
